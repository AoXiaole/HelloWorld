#ifndef __MOD_AS_PRESENCE_EVENT_H__
#define __MOD_AS_PRESENCE_EVENT_H__

#include <switch.h>
#include <list>
#include "mod_as_presence_app.h"
#include "mod_as_presence_jsonrpc.h"

#define TIME_STR_LEN    20

extern CTerminalManagement *g_cTerminalManagement;
extern CSubscriptitonRelationManagement *g_cSubscriptitonRelationManagement;
extern CTerminalStateTranscation *g_cTerminalStateTranscation;
extern SBCINFO sbcinfo;

#define MQ_SUBEVENT_RECEIVE  "MODULE_RECV_MQ_MSG"
#define MQ_SUBEVENT_SEND    "MODULE_SEND_MQ_MSG"

   
//MQ msg ��һЩ����
#define MQMSG_TYPE_STR          "type"
#define MQMSG_SEQUENCEID_STR    "sequenceid"
#define MQMSG_EXCHANGENAME_STR  "exchangename"
#define MQMSG_QUEUENAME_STR     "queuename"

#define MQMSG_ROUTINGKEY_STR    "routingKey"
#define MQMSG_EXCHANGETYPE_STR  "exchangetype"

#define MQMSG_MSGPERSISTENT_STR  "msgpersistent"

#define MQMSG_MSGBODY_STR       "msgbody"
#define MQMSG_MODULE_STR        "module"
#define MQMSG_RESULT_STR        "result"

#define MQTYPE_SUB_STR                  "sub"
#define MQTYPE_PUB_STR                  "pub"
#define MQTYPE_RECV_STR                 "recv"



#define MSGTYPE_SUBSCRIBE_STR           "subscribe"
#define MSGTYPE_UNSUBSCRIBE_STR         "unsubscribe"
#define MSGTYPE_REG_MODIFY_STR          "reg_modify"
#define MSGTYPE_REG_DEL_STR             "reg_del"
#define MSGTYPE_RESTAT_STR              "restart"
#define MSGTYPE_STATE_STR               "state"
#define MSGTYPE_SUBSCRIBEINVAILD_STR    "subscribe_invalid"

#define STATE_NULL_STR                  "null"
#define STATE_READY_STR                 "ready"
#define STATE_BUSY_STR                  "busy"




#define RESPONSE_ERROR_CODE_URI_NOT_FONUD     "404"

#define RESPONSE_ERROR_CODE_DATANOTVALIDATED     "400"

enum ExchangeType
{
    fanout,
    direct,
    topic,
    headers,
    consistent_hash
};


enum PRESENCE_MQ_TYPE
{
    MQTYPE_SUB =0,
    MQTYPE_PUB,
    MQTYPE_RECV,
    MQTYPE_MAX
};


enum PRESENCE_MSG_TYPE
{
    MSGTYPE_SUBSCRIBE = 0,
    MSGTYPE_UNSUBSCRIBE,
    MSGTYPE_REG_MODIFY,
    MSGTYPE_REG_DEL,
    
    MSGTYPE_STATE,
    MSGTYPE_RESTART,
    MSGTYPE_SUBSCRIBEINVALID,
    MSGTYPE_MAX,
    
};


struct MQ_MSG
{
    const char *pType;
    const char *pExchangename;
    
    const char *pQueuename;
    const char *pRoutingkey;
    const char *pMsgBody;
    const char *pModule;
    const char *pResult;
    
    unsigned int nSequenceid;    
    unsigned int nExchangetype;    
    unsigned int nMsgpersistent;
    MQ_MSG()
    {
        pType = NULL;
        nSequenceid = 0;
        pExchangename = NULL;
        pQueuename = NULL;
        pRoutingkey = NULL;
        nExchangetype = 1;
        pMsgBody= NULL;
        pModule = sbcinfo.pModuleName;
        pResult = NULL;
        nMsgpersistent = 2;
        
    }
    
};

const char * MsgTypeString(int nType);
int MsgTypeInt(const char * pType);

int as_presence_gettime_YMDHMS(char *pCurtimeYMDHMS);

switch_status_t as_presence_send_subMQmsg(const char *pQueuename);

switch_status_t as_presence_sendMQ_restart(const char *pSbcid);

void as_presence_presencein_event_handler(switch_event_t *event);
void as_presence_MQmsg_event_handler(switch_event_t *event);

#endif

