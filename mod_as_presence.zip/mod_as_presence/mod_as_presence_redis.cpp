#include "mod_as_presence_redis.h"
#include "mod_as_presence_app.h"
#if __cplusplus
extern "C" {
#include "../mod_as_dbcache/mod_as_dbcache.h"
}
#else
#include "../mod_as_dbcache/mod_as_dbcache.h"
#endif
#include "mod_as_presence_event.h"
#include <switch_json.h>

static switch_status_t redis_callback_getsbcinfo(_In_ ST_DB_CACHE_QUEUE_RESP_DATA *data, _Inout_opt_ void *pSbcInfoStr)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    
    if (NULL == data || NULL == pSbcInfoStr)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. data:%p pSbcInfoStr:%p\n", 
            (void*)data, (void *)pSbcInfoStr);
        return SWITCH_STATUS_INTR;
    }

    if (EN_TYPE_REDIS != data->resptype || NULL == data->respdata)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
            "This is not a redis response type data or return value is NULL. "
            "resptype:%d, respdata:%p\n", 
            data->resptype, data->respdata);
        return SWITCH_STATUS_FALSE;
    }

    strncpy((char *)pSbcInfoStr, (char *)data->respdata, REDIS_SBC_INFO_LEN);
    return SWITCH_STATUS_SUCCESS;
}


static switch_status_t redis_callback_getterminalinfo(_In_ ST_DB_CACHE_QUEUE_RESP_DATA *data, _Inout_opt_ void *pTerminaInfo)
{
    
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    
    if (NULL == data || NULL == pTerminaInfo)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. data:%p pTerminaInfo :%p\n", 
            (void*)data, (void *)pTerminaInfo);
        return SWITCH_STATUS_INTR;
    }

    if (EN_TYPE_REDIS != data->resptype || NULL == data->respdata)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
            "This is not a redis response type data or return value is NULL. "
            "resptype:%d, respdata:%p\n", 
            data->resptype, data->respdata);
        return SWITCH_STATUS_FALSE;
    }

    strncpy((char *)pTerminaInfo, (char *)data->respdata, REDIS_TERMINAL_INFO_LEN);

    return SWITCH_STATUS_SUCCESS;
}


/*****************************************************************************
  �� �� ��  : as_presence_redis_get_sbc_info
  ��������  ��ȡsbc ����Ϣ
  �������  :pSbcIp: SBC ip
  �������  : pSbcInfoStr : ����sbcinfo ��buff
  �� �� ֵ  :  �ɹ����� SWITCH_STATUS_SUCCESS��ʧ�ܷ��� SWITCH_STATUS_FALSE
*****************************************************************************/

switch_status_t as_presence_redis_get_sbc_info(const char *pSbcIp, char *pSbcInfoStr)
{
    ST_DB_CACHE_EVENT event;

    if(NULL == pSbcIp || NULL == pSbcInfoStr)
    {
         switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. pSbcIp:%p pSbcInfoStr :%p\n", 
            (void*)pSbcIp, (void *)pSbcInfoStr);
        return SWITCH_STATUS_FALSE;
    }
    
    memset(&event,0,sizeof(ST_DB_CACHE_EVENT));

    event.type = EN_TYPE_REDIS;
    switch_snprintf(event.redis_command, DB_QUERY_COMMAND_MAX_LEN, "GET SBC:INFO:%s", pSbcIp);
    event.pfunredis = redis_callback_getsbcinfo;
    event.pfunmysql = NULL;
    event.iscache = SWITCH_FALSE;
    event.timeout = 5;
    if (SWITCH_STATUS_SUCCESS != mod_as_dbcache_query(&event, (void *)pSbcInfoStr))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "mod_as_dbcache_query failed\n");
        return SWITCH_STATUS_FALSE;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
                "as_presence_redis_get_terminalstate success\n");

    return SWITCH_STATUS_SUCCESS;
}


/*****************************************************************************
  �� �� ��  : as_presence_redis_get_terminal_info
  ��������  ��ȡ�ն� ����Ϣ
  �������  :pTermURI: �ն�uri 
  �������  : pTerminaInfo : �����ն� ��buff
  �� �� ֵ  :  �ɹ����� SWITCH_STATUS_SUCCESS��ʧ�ܷ��� SWITCH_STATUS_FALSE
*****************************************************************************/

switch_status_t as_presence_redis_get_terminal_info(const char *pTermURI, char *pTerminaInfo)
{
    ST_DB_CACHE_EVENT event;

    if(NULL == pTermURI || NULL == pTerminaInfo)
    {
         switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. pTermURI:%p pTerminaInfo :%p\n", 
            (void*)pTermURI, (void *)pTerminaInfo);
        return SWITCH_STATUS_FALSE;
    }
    
    memset(&event,0,sizeof(ST_DB_CACHE_EVENT));

    event.type = EN_TYPE_REDIS;
    switch_snprintf(event.redis_command, DB_QUERY_COMMAND_MAX_LEN, "GET SUBSCRIBE:URI:STATE:%s", pTermURI);
    event.pfunredis = redis_callback_getterminalinfo;
    event.pfunmysql = NULL;
    event.iscache = SWITCH_FALSE;
    event.timeout = 5;
    if (SWITCH_STATUS_SUCCESS != mod_as_dbcache_query(&event, (void *)pTerminaInfo))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "mod_as_dbcache_query failed\n");
        return SWITCH_STATUS_FALSE;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
                "as_presence_redis_get_terminalstate success\n");

    return SWITCH_STATUS_SUCCESS;
}

/*****************************************************************************
  �� �� ��  : as_presence_redis_set_terminal_info
  ��������  �����ն� ����Ϣ
  �������  :pTermURI: �ն�uri ��pTerminaInfo : �ն� ��Ϣjson�ַ���
  �������  : 
  �� �� ֵ  :  �ɹ����� SWITCH_STATUS_SUCCESS��ʧ�ܷ��� SWITCH_STATUS_FALSE
*****************************************************************************/
switch_status_t as_presence_redis_set_terminal_info(const char *pTermURI, const char *pTerminaInfo)
{
    ST_DB_CACHE_EVENT event;
    
    memset(&event,0,sizeof(ST_DB_CACHE_EVENT));
    if (NULL == pTermURI || NULL == pTerminaInfo)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. pTermURI:%p pTerminaInfo :%p\n", 
            (void*)pTermURI, (void *)pTerminaInfo);
        return SWITCH_STATUS_FALSE;
    }
    event.type = EN_TYPE_REDIS;
    switch_snprintf(event.redis_command, DB_QUERY_COMMAND_MAX_LEN, "SET SUBSCRIBE:URI:STATE:%s %s", pTermURI, pTerminaInfo);
    event.pfunredis = NULL;
    event.pfunmysql = NULL;
    event.iscache = SWITCH_FALSE;
    event.timeout = 5;
    if (SWITCH_STATUS_SUCCESS != mod_as_dbcache_query(&event, NULL))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "mod_as_dbcache_query failed\n");
        return SWITCH_STATUS_FALSE;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
         "as_presence_redis_set_terminalstatus success\n");

    return SWITCH_STATUS_SUCCESS;
}

/*****************************************************************************
  �� �� ��  : as_presence_redis_get_sbcid
  ��������  �õ�sbc��id
  �������  :pSbcIp : sbcip
  �������  : pSbcId : sbcid buff
  �� �� ֵ  :  �ɹ����� SWITCH_STATUS_SUCCESS��ʧ�ܷ��� SWITCH_STATUS_FALSE
*****************************************************************************/
switch_status_t as_presence_redis_get_sbcid(const char *pSbcIp, char *pSbcId)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;    
    char szSbcInfoStr[REDIS_SBC_INFO_LEN + 1] = {0};
    cJSON *pJson = NULL;
    char *pState = NULL;

    if(NULL == pSbcIp || NULL == pSbcId)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. pSbcIp:%p pSbcId :%p\n", 
            (void*)pSbcIp, (void *)pSbcId);
        return SWITCH_STATUS_FALSE;
    }
    
    nRet = as_presence_redis_get_sbc_info(pSbcIp,szSbcInfoStr);
    if(SWITCH_STATUS_SUCCESS == nRet)
    {
        
        pJson = cJSON_Parse(szSbcInfoStr);
        if(NULL == pJson)
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
                "cJSON_Parse failed\n");
            return SWITCH_STATUS_FALSE;
        }

        pState = (char *)cJSON_GetObjectCstr(pJson, JSON_ID_KEY);
        if(pState)
        {
            strncpy(pSbcId,pState,strlen(pState));
            nRet = SWITCH_STATUS_SUCCESS;
        }
        else
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
                "cJSON_GetObjectCstr failed\n");
            nRet = SWITCH_STATUS_FALSE;
        }
        cJSON_Delete(pJson);
    }
    
    return nRet;
    
}

/*****************************************************************************
  �� �� ��  : as_presence_redis_get_terminal_state
  ��������  �õ��ն�״̬
  �������  :pTermURI : �ն�uri
  �������  : pTerminalStateStr : �ն�״̬�ַ���buff 
  �� �� ֵ  :  �ɹ����� SWITCH_STATUS_SUCCESS��ʧ�ܷ��� SWITCH_STATUS_FALSE
*****************************************************************************/
switch_status_t as_presence_redis_get_terminal_state(const char *pTermURI, char *pTerminalStateStr)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;    
    char szTerminalInfoStr[REDIS_TERMINAL_INFO_LEN + 1] = {0};
    cJSON *pJson = NULL;
    char *pState = NULL;

    if(NULL == pTermURI || NULL == pTerminalStateStr)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. pTermURI:%p pTerminalStateStr:%p\n", 
            (void*)pTermURI, (void *)pTerminalStateStr);
        return SWITCH_STATUS_FALSE;
    }
    
    nRet = as_presence_redis_get_terminal_info(pTermURI,szTerminalInfoStr);
    if(SWITCH_STATUS_SUCCESS == nRet)
    {
        
        pJson = cJSON_Parse(szTerminalInfoStr);
    	if(NULL == pJson)
    	{
    		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "cJSON_Parse failed\n");
    		return SWITCH_STATUS_FALSE;
    	}

        
        pState = (char *)cJSON_GetObjectCstr(pJson, JSON_STATE_KEY);
        if(pState)
        {
            strncpy(pTerminalStateStr,pState,strlen(pState));
            nRet = SWITCH_STATUS_SUCCESS;
        }
        else
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
                "cJSON_GetObjectCstr error\n");
            
            nRet = SWITCH_STATUS_FALSE;
        }
        cJSON_Delete(pJson);
    }
    
    return nRet;
    
}

/*****************************************************************************
  �� �� ��  : as_presence_redis_set_terminal_state
  ��������  �����ն�״̬
  �������  :pTermURI : �ն�uri��pTerminalStateStr : �ն�״̬�ַ���
  �������  : 
  �� �� ֵ  :  �ɹ����� SWITCH_STATUS_SUCCESS��ʧ�ܷ��� SWITCH_STATUS_FALSE
*****************************************************************************/
switch_status_t as_presence_redis_set_terminal_state(const char *pTermURI, const char *pTerminalStateStr)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    char *pTerminalInfoStr = NULL;
    char szTerminalInfoStr[REDIS_TERMINAL_INFO_LEN + 1]={0};
    cJSON *pJson = NULL;
    
    char szCurtimeYMDHMS[TIME_STR_LEN] = {0};
    
    if(NULL == pTermURI || NULL == pTerminalStateStr)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "Input parameter(s) is NULL. pTermURI:%p pTerminalStateStr:%p\n", 
            (void*)pTermURI, (void *)pTerminalStateStr);
        
        return SWITCH_STATUS_FALSE;
    }
   
    as_presence_gettime_YMDHMS(szCurtimeYMDHMS);
    
    pJson = cJSON_CreateObject();
	if(NULL == pJson)
	{
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
            "cJSON_Parse failed\n");
		return SWITCH_STATUS_FALSE;
	}

    cJSON_AddItemToObject(pJson, JSON_URI_KEY, cJSON_CreateString(pTermURI));
    cJSON_AddItemToObject(pJson, JSON_STATE_KEY, cJSON_CreateString(pTerminalStateStr));
    cJSON_AddItemToObject(pJson, JSON_SBCID_KEY, cJSON_CreateString(sbcinfo.szSbcId));
    cJSON_AddItemToObject(pJson, JSON_DATE_KEY, cJSON_CreateString(szCurtimeYMDHMS));
    pTerminalInfoStr = cJSON_Print(pJson);
    if(NULL == pTerminalInfoStr)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
                "cJSON_Print error\n");
        nRet = SWITCH_STATUS_FALSE;
    }
    else
    {
        nRet = as_presence_redis_set_terminal_info(pTermURI, pTerminalInfoStr);

        free(pTerminalInfoStr);
    }

    cJSON_Delete(pJson);

   return nRet;
}

