#ifndef __MOD_AS_PRESENCE_APP_H__
#define __MOD_AS_PRESENCE_APP_H__

#include <map>
#include <switch.h>
#include <string>
#include <pthread.h>

using namespace std;

#define MAX_ACCOUNT_LEN 32
#define MAX_SEATGWID_LEN 32
#define MAX_URI_LEN 128
#define MAX_TERMINAL_COUNT 5000
#define MAXSTATE_STRINGLEN 24
#define SBCID_LEN   20
#define SBCIP_LEN  20
#define EXCHANGENAME_LEN    64
#define ROUTINGKEY_LEN      64
#define QUEUENAME_LEN       64
#define CHANNELID_LEN       64
#define SUBEVENT_LEN        64

#define SBC_MODULENAME      "mod_as_presence"
#define REGISTER_SHELL_CMD_LEN  256

typedef enum
{
    ESL_SUBSCRIBE_EVENT_REGISTERED = 0,
    ESL_SUBSCRIBE_EVENT_UNREGISTERED,
    ESL_SUBSCRIBE_EVENT_HANGUP,
    ESL_SUBSCRIBE_EVENT_OTHER,
    ESL_SUBSCRIBE_EVENT_MAX,
}PRESENCE_ESL_SUBSCRIBE_EVENT;

typedef enum
{
    ESL_CALLING_STATE_HANGUP = 0,
    ESL_CALLING_STATE_NULL,
    ESL_CALLING_STATE_OTHER,
    ESL_CALLING_STATE_MAX,
}PRESENCE_ESL_CALLING_STATE;

typedef enum
{
    TERMINAL_STATE_NULL = 0,
    TERMINAL_STATE_READY,
    TERMINAL_STATE_BUSY,
    TERMINAL_STATE_MAX,
}PRESENCE_TERMINAL_STATE;

typedef struct st_SBCINFO
{
    char szSbcId[SBCID_LEN + 1];
    char szIp[SBCIP_LEN + 1];
    char szSbcQueueName[QUEUENAME_LEN + 1];
    char szSbcWebQueueName[QUEUENAME_LEN + 1];
    char szSeatGwEvent[SUBEVENT_LEN + 1];
    char szWebEvent[SUBEVENT_LEN + 1];
    const char *pModuleName;
    
    int nSbcQueueSubFlag;   // 0 ��ʾû�ж��ĳɹ� ��1 ��ʾ���ĳɹ�
    int nSbcWebQueueSubFlag; // 0 ��ʾû�ж��ĳɹ� ��1 ��ʾ���ĳɹ�
}SBCINFO;

class CTerminalManagement
{
public:
    CTerminalManagement();
    virtual ~CTerminalManagement();

public:
    int DelTerminalState(const char *pcURI);
    int GetTerminalState(const char *pcURI);
    int ModifyTerminalState(const char *pcURI);
    void RefreshAllTerminalState();
    int RefreshOneTerminalState(const char *pcURI);
    int GetOneDataBaseTerminalState(const char *pcURI);
    int UpdateTerminalState(const char *pcURI, const int nStatus);
    void ListAllTerminalState();
    
private: 
    map<string, int> m_mapUriIndex;
    int m_sznState[MAX_TERMINAL_COUNT];  // ״̬ 0 TERMINAL_STATE_NULL ; 1 TERMINAL_STATE_READY ; 2 TERMINAL_STATE_BUSY
    int m_nCurIndex;
    pthread_mutex_t m_pstUriIndexLock;
};

class CSubscriptitonRelationManagement
{
public:
    CSubscriptitonRelationManagement();
    virtual ~CSubscriptitonRelationManagement();

public:
    int AddRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount);
    int DelRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount);
    int UpdateRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount);
    int CheckRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount);
    int GetRelation(const char *pcURI, char *pcSeatGwId, int nSeatGwIdLen, char *pcAccount, int nAccountLen);
    void ListAllRelation();
    
private:
    typedef struct Relation_Info
    {
        char m_szcAccount[MAX_ACCOUNT_LEN];
        char m_szcSeatGwId[MAX_SEATGWID_LEN];
    }CSubscriptitonRelationInfo;

private:
    map<string, int> m_mapUriIndex;
    CSubscriptitonRelationInfo m_szstRelationInfo[MAX_TERMINAL_COUNT];
    int m_nCurIndex;
    pthread_mutex_t m_pstUriIndexLock;
};


class CTerminalStateTranscation
{
public:
    CTerminalStateTranscation();
    virtual ~CTerminalStateTranscation();
    int Transaction(int nSubscribeEvent, int nCallingState, int nCurTerminalState);

    static int GetStateInt(const char *pSate);
    static const char * GetStateString(int nState);
    
private:
    PRESENCE_TERMINAL_STATE m_szStateTable[ESL_SUBSCRIBE_EVENT_MAX][ESL_CALLING_STATE_MAX][TERMINAL_STATE_MAX];
    static const char * const m_szpState[TERMINAL_STATE_MAX]; // �ն�״̬ö��ֵ��Ӧ���ַ���
    
};


#endif
