#include "mod_as_presence_event.h"

#include "mod_as_presence_jsonrpc.h"

JsonBase::~JsonBase()
{
}

cJSON *JsonBase::Json()
{
   return NULL;
} 

switch_status_t JsonBase::DecodeJson(cJSON *pJson)
{
    return SWITCH_STATUS_FALSE;
}

Json_SubReq_ListNode::Json_SubReq_ListNode(): pAccount(NULL), pSeatgwId(NULL), pUri(NULL)
{
}  

switch_status_t Json_SubReq_ListNode:: DecodeJson(cJSON *pJson)
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;
    if(NULL == pJson)
    {
        return SWITCH_STATUS_FALSE;
    }
    GETJSONVALUE_RETURN(pJson, JSON_ACCOUNT_KEY, pAccount, 1);
    GETJSONVALUE_RETURN(pJson, JSON_SEATGWID_KEY, pSeatgwId, 1);
    GETJSONVALUE_RETURN(pJson, JSON_URI_KEY, pUri, 1);
    return nRet;
}

Json_RegModifyReq_ListNode::Json_RegModifyReq_ListNode():pNum(NULL), pDomain(NULL), pIp(NULL), pPort(NULL), pPwd(NULL), pCodec(NULL)
{
}
switch_status_t Json_RegModifyReq_ListNode:: DecodeJson(cJSON *pJson)
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;
    if(NULL == pJson)
    {
        return SWITCH_STATUS_FALSE;
    }

    GETJSONVALUE_RETURN(pJson, JSON_NUM_KEY, pNum, 1);
    GETJSONVALUE_RETURN(pJson, JSON_DOMAIN_KEY, pDomain, 1);
    GETJSONVALUE_RETURN(pJson, JSON_IP_KEY, pIp, 1);
    GETJSONVALUE_RETURN(pJson, JSON_PORT_KEY, pPort, 1);
    GETJSONVALUE_RETURN(pJson, JSON_PWD_KEY, pPwd, 1);
    GETJSONVALUE_RETURN(pJson, JSON_CODEC_KEY, pCodec, 0);
    return nRet;
}

Json_RegDelReq_ListNode::Json_RegDelReq_ListNode():pNum(NULL), pDomain(NULL)
{
}
switch_status_t Json_RegDelReq_ListNode::DecodeJson(cJSON *pJson)
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;
    if(NULL == pJson)
    {
        return SWITCH_STATUS_FALSE;
    }

    GETJSONVALUE_RETURN(pJson, JSON_NUM_KEY, pNum, 1);
    GETJSONVALUE_RETURN(pJson, JSON_DOMAIN_KEY, pDomain, 1);
    return nRet;
}

Json_StateNotify_ListNode::Json_StateNotify_ListNode():pAccount(NULL), pSeatgwId(NULL), pState(NULL), pUri(NULL), pSbcId(NULL)
{
}

cJSON *Json_StateNotify_ListNode::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON_AddItemToObject(pJson, JSON_ACCOUNT_KEY,  cJSON_CreateString(pAccount));
    cJSON_AddItemToObject(pJson, JSON_SEATGWID_KEY, cJSON_CreateString(pSeatgwId));
    cJSON_AddItemToObject(pJson, JSON_STATE_KEY,    cJSON_CreateString(pState));
    cJSON_AddItemToObject(pJson, JSON_URI_KEY,      cJSON_CreateString(pUri));
    cJSON_AddItemToObject(pJson, JSON_SBCID_KEY,    cJSON_CreateString(pSbcId));
    return pJson;
}

Json_SubInvalidNotify_ListNode::Json_SubInvalidNotify_ListNode():pAccount(NULL), pSeatgwId(NULL), pUri(NULL), pSbcId(NULL)
{
}

cJSON *Json_SubInvalidNotify_ListNode::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON_AddItemToObject(pJson, JSON_ACCOUNT_KEY,  cJSON_CreateString(pAccount));
    cJSON_AddItemToObject(pJson, JSON_SEATGWID_KEY, cJSON_CreateString(pSeatgwId));
    cJSON_AddItemToObject(pJson, JSON_URI_KEY,      cJSON_CreateString(pUri));
    cJSON_AddItemToObject(pJson, JSON_SBCID_KEY,    cJSON_CreateString(pSbcId));
    return pJson;
}

cJSON *Json_Req_Param::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON_AddItemToObject(pJson, JSON_DATE_KEY, cJSON_CreateString(pDate));
    cJSON_AddItemToObject(pJson, JSON_OBJLIST_KEY, pObjList->Json());
    
    return pJson;
}

Json_Req_Param::Json_Req_Param() : pObjList(NULL), pDate(NULL)
{

}
Json_Req_Param::Json_Req_Param(int nMsgType)
{
    
}

Json_Req_Param::~Json_Req_Param()
{
    if(pObjList)
    {
        delete pObjList;
    }
}

switch_status_t Json_Req_Param::DecodeJson(cJSON *pJson)
{
  switch_status_t nRet = SWITCH_STATUS_SUCCESS;
  cJSON *pListJson = NULL;
  
  if(NULL == pJson)
  {
      return SWITCH_STATUS_FALSE;
  }
  
  GETJSONVALUE_RETURN(pJson, JSON_DATE_KEY, pDate, 1);
  GETJSONOBJ_RETURN(pJson, JSON_OBJLIST_KEY, pListJson, 1);
  nRet = pObjList->DecodeJson(pListJson);
  
  return nRet;
}

Json_SubInvalidNotify_Param::Json_SubInvalidNotify_Param(JsonBase *pOldList_, JsonBase *pNewList_):pDate(NULL),pOldList(pOldList_),pNewList(pNewList_)
{
}

Json_SubInvalidNotify_Param:: ~Json_SubInvalidNotify_Param()   
{
    if(pOldList)
    {
        delete pOldList;
    }
    if(pNewList)
    {
        delete pNewList;
    }
}

cJSON *Json_SubInvalidNotify_Param::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON_AddItemToObject(pJson, JSON_DATE_KEY, cJSON_CreateString(pDate));
    cJSON_AddItemToObject(pJson, JSON_OLDLIST_KEY, pOldList->Json());
    cJSON_AddItemToObject(pJson, JSON_NEWLIST_KEY, pNewList->Json());
    return pJson;
}

Json_RestartNotify_Param::Json_RestartNotify_Param():pDate(NULL), pSbcId(NULL)
{
}

cJSON *Json_RestartNotify_Param::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON_AddItemToObject(pJson, JSON_DATE_KEY, cJSON_CreateString(pDate));
    cJSON_AddItemToObject(pJson, JSON_SBCID_KEY, cJSON_CreateString(pSbcId));
    return pJson;
}

Json_Response_Param::Json_Response_Param():pDate(NULL), pReason(NULL), pListSuccess(NULL), pListFailure(NULL)
{
}

cJSON *Json_Response_Param::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON *pSuccessListJson = cJSON_CreateArray();
    cJSON *pFailureListJson = cJSON_CreateArray();

    cJSON_AddItemToObject(pJson, JSON_DATE_KEY, cJSON_CreateString(this->pDate));

    cJSON_AddItemToObject(pJson, JSON_REASON_KEY, cJSON_CreateString(this->pReason));

    if(this->pListSuccess)
    {
        
        list<string>::iterator it=this->pListSuccess->begin();
        for(; it != this->pListSuccess->end(); it++)
        {
            cJSON_AddItemToArray(pSuccessListJson, cJSON_CreateString(it->c_str()));
        }
        
    }
    cJSON_AddItemToObject(pJson, JSON_SUCCESSLIST_KEY, pSuccessListJson);

    if(this->pListFailure)
    {
        
        list<string>::iterator it=this->pListFailure->begin();
        for(; it != this->pListFailure->end(); it++)
        {
            cJSON_AddItemToArray(pFailureListJson, cJSON_CreateString(it->c_str()));
        }
        
    }
    cJSON_AddItemToObject(pJson, JSON_FAILURELIST_KEY, pFailureListJson);

    return  pJson;
}    

cJSON *JsonrpcObj::Json()
{
   switch_status_t nRet = SWITCH_STATUS_SUCCESS;
   
   cJSON *pJson = cJSON_CreateObject();

   cJSON_AddItemToObject(pJson, JSON_JSONRPC_KEY,  cJSON_CreateString(pJsonrpc));
   if(pId)
   {
        cJSON_AddItemToObject(pJson, JSON_ID_KEY,   cJSON_CreateString(pId));
   }
   
   if(pMethod)
   {
        nJsonType = JsonType_method;
   }
   else if(pResult)
   {
        nJsonType = JsonType_result;
   }
    
   switch(nJsonType)
   {
       case JsonType_method:
           cJSON_AddItemToObject(pJson, JSON_METHOD_KEY, cJSON_CreateString(pMethod));
           cJSON_AddItemToObject(pJson, JSON_PARAMS_KEY, UserData.pParam->Json());
           break;
       case JsonType_result:
           cJSON_AddItemToObject(pJson, JSON_RESULT_KEY, cJSON_CreateString(pResult));
           cJSON_AddItemToObject(pJson, JSON_DATA_KEY, UserData.pData->Json());
           break;
       default:
           nRet = SWITCH_STATUS_FALSE;
   }
   
   if(SWITCH_STATUS_FALSE == nRet)
   {
       cJSON_Delete(pJson);
       pJson =  NULL;
   }

   return pJson;
}

JsonrpcObj::JsonrpcObj():nJsonType(invalid), pJsonrpc(NULL), pId(NULL), pMethod(NULL), pResult(NULL)
{
    memset(&UserData, 0, sizeof(UserData));
}

JsonrpcObj::JsonrpcObj(int nJsonType_, int nMsgtype_):pJsonrpc(NULL), pId(NULL), pMethod(NULL), pResult(NULL)
{
    nJsonType = nJsonType_;
    msgType = nMsgtype_
    //memset(&UserData, 0, sizeof(UserData));
    if(JsonType_result == nMsgtype_)
    {
       switch(msgType)
       {
           case MSGTYPE_SUBSCRIBE:
           case MSGTYPE_UNSUBSCRIBE:
           case MSGTYPE_REG_MODIFY:
           case MSGTYPE_REG_DEL:
               UserData.pData = new Json_Response_Param();
               break;
           default:
               UserData.pData = new Json_Response_Param();
       }
    }
    else
    {
        switch(msgType)
        {
           case MSGTYPE_SUBSCRIBE:
               UserData.pParam = new Json_SubReq_Param(new Json_List<Json_SubReq_ListNode>());
               break;
           case MSGTYPE_UNSUBSCRIBE:
               UserData.pParam = new Json_UnsubReq_Param(new Json_List<Json_UnsubReq_ListNode>());
               break;
               
           case MSGTYPE_REG_MODIFY:
               UserData.pParam = new Json_RegModifyReq_Param(new Json_List<Json_RegModifyReq_ListNode>());
               break;
               
           case MSGTYPE_REG_DEL:
               UserData.pParam = new Json_RegDelReq_Param(new Json_List<Json_RegDelReq_ListNode>());
               break;
           default:
              UserData.pParam = new Json_SubReq_Param(new Json_List<Json_SubReq_ListNode>());
              break;
       }
    }
}

JsonrpcObj:: ~JsonrpcObj()
{
    if(JsonType_method == nJsonType)
    {
        if(UserData.pParam)
        {
            delete UserData.pParam;
        }
    }
    else
    {
        if(UserData.pData)
        {
            delete UserData.pData;
        }
    }
}

switch_status_t JsonrpcObj::DecodeJson(cJSON *pJson)
{
   switch_status_t nRet = SWITCH_STATUS_SUCCESS;

   cJSON *pSubJson = NULL;
   if(NULL == pJson)
   {
       return SWITCH_STATUS_FALSE;
   }
   
   // ������Ϣ����
   pMethod = cJSON_GetObjectCstr(pJson, JSON_METHOD_KEY);
   if(NULL == pMethod)
   {
       pResult = cJSON_GetObjectCstr(pJson, JSON_RESULT_KEY);
       if(NULL == pResult)
       {
           return SWITCH_STATUS_FALSE;
       }
       else
       {
           msgType = MsgTypeInt(pResult);
           nJsonType = JsonType_result;
           switch(msgType)
           {
               case MSGTYPE_SUBSCRIBE:
               case MSGTYPE_UNSUBSCRIBE:
               case MSGTYPE_REG_MODIFY:
               case MSGTYPE_REG_DEL:
                   UserData.pData = new Json_Response_Param();
                   break;
               default:
                  return SWITCH_STATUS_FALSE; 

           }
       }
   }
   else
   {
       msgType = MsgTypeInt(pMethod);
       nJsonType = JsonType_method;

       switch(msgType)
       {
           case MSGTYPE_SUBSCRIBE:
               UserData.pParam = new Json_SubReq_Param(new Json_List<Json_SubReq_ListNode>());
               break;
           case MSGTYPE_UNSUBSCRIBE:
               UserData.pParam = new Json_UnsubReq_Param(new Json_List<Json_UnsubReq_ListNode>());
               break;
               
           case MSGTYPE_REG_MODIFY:
               UserData.pParam = new Json_RegModifyReq_Param(new Json_List<Json_RegModifyReq_ListNode>());
               break;
               
           case MSGTYPE_REG_DEL:
               UserData.pParam = new Json_RegDelReq_Param(new Json_List<Json_RegDelReq_ListNode>());
               break;
               
           default:
              return SWITCH_STATUS_FALSE; 

       }
   }

   // ����

   GETJSONVALUE_RETURN(pJson, JSON_JSONRPC_KEY, pJsonrpc, 1);
   GETJSONVALUE_RETURN(pJson, JSON_ID_KEY, pId, 1);

   if(JsonType_method == nJsonType)
   {
       GETJSONOBJ_RETURN(pJson, JSON_PARAMS_KEY, pSubJson, 1);
       
       nRet = UserData.pParam->DecodeJson(pSubJson);
   }
   else
   {
       GETJSONOBJ_RETURN(pJson, JSON_DATA_KEY, pSubJson, 1);
       nRet = UserData.pData->DecodeJson(pSubJson);
   }

   return nRet;
   
}


MsgJsonString:: MsgJsonString(const char *pMsgString_)
{
    pMsgString = pMsgString_;
    pMsgJson= NULL;
    pMsgObj = NULL;
}

MsgJsonString:: MsgJsonString(int nJsonType, int nMsgtype)
{
    pMsgString = NULL;
    pMsgJson= NULL;
    pMsgObj = new JsonrpcObj(nJsonType, nMsgtype);
}

MsgJsonString::~MsgJsonString()
{
   if(pMsgJson) 
   {
       cJSON_Delete(pMsgJson);
   }
   
   if(pMsgObj) 
   {
       delete pMsgObj;
   }
   
   if(pMsgString)
   {
       delete pMsgString;
   }
}

switch_status_t MsgJsonString::JsonStringParse(const char *pMsgBody)
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;
    if(NULL == pMsgBody)
    {
        return SWITCH_STATUS_FALSE;
    }
    if(pMsgJson) 
    {
        cJSON_Delete(pMsgJson);
        pMsgJson= NULL;
    }
    
    if(pMsgObj) 
    {
        delete pMsgObj;
        pMsgObj = NULL;
    }

    if(pMsgString)
    {
        delete pMsgString;
        pMsgString = NULL;
    }
    
    pMsgJson = cJSON_Parse(pMsgBody);
    if(NULL == pMsgJson)
    {
       return SWITCH_STATUS_FALSE;
    }

    pMsgObj = new JsonrpcObj();
    nRet = pMsgObj->DecodeJson(pMsgJson);
    
    return nRet;
}

const char *MsgJsonString::GetJsonString()
{ 
   if(!pMsgString)
   {
       if(NULL == pMsgJson)
       {
          if(NULL == pMsgObj)
          {
               return NULL;
          }
          pMsgJson = pMsgObj->Json();
       }
       
       pMsgString =  cJSON_Print(pMsgJson);
   }
   return pMsgString;
}


