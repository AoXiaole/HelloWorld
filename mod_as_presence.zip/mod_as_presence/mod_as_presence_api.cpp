#include <switch.h>

extern CTerminalManagement *g_cTerminalManagement;
extern CSubscriptitonRelationManagement *g_cSubscriptitonRelationManagement;


