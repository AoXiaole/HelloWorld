#include <switch.h>
#include <switch_json.h>
#include <string>
#include <list>
#include "mod_as_presence_app.h"
#include "mod_as_presence_event.h"
#include "mod_as_presence_redis.h"
#include "mod_as_presence_jsonrpc.h"

using namespace std;
// ����֪��·������
#define REGISTER_SHELL_FILE "/usr/local/freeswitch/scripts/register_xml_producer.sh"

//��MSG_TYPE  ��ö�ٶ�Ӧ
const char * const g_szMQTypeStr[MQTYPE_MAX] = {
    MQTYPE_SUB_STR,
    MQTYPE_PUB_STR,
    MQTYPE_RECV_STR,
};

//��MSG_TYPE  ��ö�ٶ�Ӧ
const char * const g_szMsgTypeStr[MSGTYPE_MAX] = {
    MSGTYPE_SUBSCRIBE_STR,
    MSGTYPE_UNSUBSCRIBE_STR,
    MSGTYPE_REG_MODIFY_STR,
    MSGTYPE_REG_DEL_STR,

    MSGTYPE_STATE_STR,
    MSGTYPE_RESTAT_STR,
    MSGTYPE_SUBSCRIBEINVAILD_STR,

};


int MQTypeInt(const char * pType)
{
    int m = 0;
    if (NULL == pType)
    {
        return (int)MQTYPE_MAX;
    }
    
    for(m = MQTYPE_SUB; m < MQTYPE_MAX; m++)
    {
        if (strcmp(pType, g_szMQTypeStr[m]) == 0)
        {
            break;
        }
    }
    
    return m ;
}

const char * MQTypeString(int nType)
{
    if(nType >= 0 && nType < MQTYPE_MAX)
    {
        return g_szMQTypeStr[nType];
    }
    else
    {
        return NULL;
    }
}


/*****************************************************************************
  �� �� ��  : MsgTypeInt
  ��������  : ����msg method �ֶεõ���Ӧ��ö��ֵ
  �������  : 
  �������  :
  �� �� ֵ  :  û�ж�Ӧ��ϵ���� MSG_TYPE_MAX 
*****************************************************************************/

int MsgTypeInt(const char * pType)
{
    int m = 0;
    if (NULL == pType)
    {
        return (int)MSGTYPE_MAX;
    }
    
    for(m = MSGTYPE_SUBSCRIBE; m < MSGTYPE_MAX; m++)
    {
        if (strcmp(pType, g_szMsgTypeStr[m]) == 0)
        {
            break;
        }
    }
    
    return m ;
}

/*****************************************************************************
  �� �� ��  : MsgTypeString
  ��������  : ����msg type ��ö��ֵ�õ���Ӧ���ַ���
  �������  : 
  �������  :
  �� �� ֵ  :  û�ж�Ӧ��ϵ����NULL
*****************************************************************************/
const char * MsgTypeString(int nType)
{
    if(nType >= 0 && nType < MSGTYPE_MAX)
    {
        return g_szMsgTypeStr[nType];
    }
    else
    {
        return NULL;
    }
}


/*****************************************************************************
  �� �� ��  : as_presence_gettime_YMDHMS
  ��������  : ��ȡ��ǰ��������ʱ����
  �������  : pCurtimeYMDHMS : ����ʱ���ַ�����buff
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
int as_presence_gettime_YMDHMS(char *pCurtimeYMDHMS)
{
    time_t timep;
    struct tm *p;
    time(&timep);
    p = localtime(&timep); /*ȡ�õ���ʱ��*/
    switch_snprintf(pCurtimeYMDHMS, TIME_STR_LEN, "%04d%02d%02d%02d%02d%02d", (1900 + p->tm_year), (1 + p->tm_mon), p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);
    return 0;
}


/*****************************************************************************
  �� �� ��  : as_presence_send_pubMQmsg
  ��������  :������Ϣ��rabbitMQ
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
switch_status_t as_presence_send_pubMQmsg(MQ_MSG *pMqMsg)
{

    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_event_t *pevent = NULL;

    if(NULL == pMqMsg || NULL == pMqMsg->pType || NULL == pMqMsg->pExchangename || 
       NULL == pMqMsg->pQueuename || NULL == pMqMsg->pMsgBody || NULL == pMqMsg->pModule )
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "as_presence_send_pubMQmsg param error\n");
        return SWITCH_STATUS_FALSE;
    }
    
    if(SWITCH_STATUS_SUCCESS == switch_event_create_subclass(&pevent, SWITCH_EVENT_CUSTOM, MQ_SUBEVENT_SEND))
    {
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_TYPE_STR, pMqMsg->pType);
        
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_EXCHANGENAME_STR, pMqMsg->pExchangename);
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_QUEUENAME_STR, pMqMsg->pQueuename);
        
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_MODULE_STR, pMqMsg->pModule);
        
        switch_event_add_header(pevent, SWITCH_STACK_BOTTOM, MQMSG_SEQUENCEID_STR, "%d", pMqMsg->nSequenceid); //int
        switch_event_add_header(pevent, SWITCH_STACK_BOTTOM, MQMSG_EXCHANGETYPE_STR, "%d", pMqMsg->nExchangetype);
        switch_event_add_header(pevent, SWITCH_STACK_BOTTOM, MQMSG_MSGPERSISTENT_STR, "%d", pMqMsg->nMsgpersistent);

        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_MSGBODY_STR, pMqMsg->pMsgBody);
        
        if(pMqMsg->pRoutingkey)
        {
            switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_ROUTINGKEY_STR, pMqMsg->pRoutingkey);
        }
        
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, 
            "[PRINTF_DEBUG] " MQMSG_TYPE_STR ":%s\n"
            MQMSG_EXCHANGENAME_STR ":%s\n"
            MQMSG_QUEUENAME_STR ":%s\n"
            MQMSG_ROUTINGKEY_STR ":%s\n"
            MQMSG_MSGBODY_STR ":%s\n"
            MQMSG_MODULE_STR ":%s\n",
            pMqMsg->pType, pMqMsg->pExchangename, pMqMsg->pQueuename, pMqMsg->pRoutingkey? pMqMsg->pRoutingkey: "NULL", 
            pMqMsg->pMsgBody, pMqMsg->pModule
            );
    
        switch_event_fire(&pevent); 
        nRet = SWITCH_STATUS_SUCCESS;
        
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Create event failed");
        nRet = SWITCH_STATUS_FALSE;
    }
    return nRet;
    
}

switch_status_t as_presence_send_subMQmsg(const char *pQueuename)
{

    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_event_t *pevent = NULL;

    if(NULL == pQueuename)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "as_presence_send_subMQmsg param error\n");
        return SWITCH_STATUS_FALSE;
    }
    
    if(SWITCH_STATUS_SUCCESS == switch_event_create_subclass(&pevent, SWITCH_EVENT_CUSTOM, MQ_SUBEVENT_SEND))
    {
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_TYPE_STR, MQTYPE_SUB_STR);
        
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_QUEUENAME_STR, pQueuename);
        
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, 
            "[PRINTF_DEBUG] "
            MQMSG_QUEUENAME_STR ":%s\n",
            pQueuename
            );
    
        switch_event_fire(&pevent); 
        nRet = SWITCH_STATUS_SUCCESS;
        
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Create event failed");
        nRet = SWITCH_STATUS_FALSE;
    }
    return nRet;
    
}



switch_status_t as_presence_send_MQmsg_seatgw(const char *pSeatgwid, const char * pMsgBody)
{
    char szRoutingKey[ROUTINGKEY_LEN + 1] = {0};
    char szQueueName[QUEUENAME_LEN + 1] = {0};

    MQ_MSG mqMsg ;

    switch_snprintf(szQueueName, QUEUENAME_LEN, "q_%s", pSeatgwid);
    switch_snprintf(szRoutingKey, ROUTINGKEY_LEN, "k_%s", pSeatgwid);
    
    mqMsg.pType = MQTYPE_PUB_STR;
    mqMsg.nSequenceid = 0;
    mqMsg.pExchangename = "ex_seatgw";
    mqMsg.pQueuename    = szQueueName;
    mqMsg.pRoutingkey   = szRoutingKey;
    mqMsg.nExchangetype = direct;
    mqMsg.pMsgBody      = pMsgBody;
    mqMsg.pModule       = sbcinfo.pModuleName;
    mqMsg.nMsgpersistent = 2;
    return as_presence_send_pubMQmsg(&mqMsg);
}

switch_status_t as_presence_send_MQmsg_web(const char * pMsgBody)
{
    MQ_MSG mqMsg;
    mqMsg.pType = MQTYPE_PUB_STR;
    mqMsg.nSequenceid = 0;
    mqMsg.pExchangename = "ex_sbc_web";
    mqMsg.pQueuename    = "q_sbc_web";
    mqMsg.pRoutingkey   = "k_sbc_web";
    mqMsg.nExchangetype = direct;
    mqMsg.pMsgBody      = pMsgBody;
    mqMsg.pModule       = sbcinfo.pModuleName;
    mqMsg.nMsgpersistent = 2;
    return as_presence_send_pubMQmsg(&mqMsg);
}

switch_status_t as_presence_send_MQmsg_seatgwbroadcast(const char * pMsgBody)
{
    MQ_MSG mqMsg;
    mqMsg.pType = MQTYPE_PUB_STR;
    mqMsg.nSequenceid = 0;
    mqMsg.pExchangename = "ex_sbc_broadcast";
    mqMsg.pQueuename    = "q_sbc_broadcast";
    mqMsg.pRoutingkey   = "broadcast";
    mqMsg.nExchangetype = fanout;
    mqMsg.pMsgBody      = pMsgBody;
    mqMsg.pModule       = sbcinfo.pModuleName;
    mqMsg.nMsgpersistent = 2;
    return as_presence_send_pubMQmsg(&mqMsg);
}

/*****************************************************************************
  �� �� ��  : as_presence_sendMQ_restart
  ��������  sbc ģ������������sbc������Ϣ
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/

switch_status_t as_presence_sendMQ_restart(const char *pSbcid)
{

    switch_status_t nRet = SWITCH_STATUS_FALSE;
    char sztime_ymdhms[TIME_STR_LEN +1] = {0};
    const char *pMsgBody = NULL;
    JsonrpcObj *pJsonObj = new JsonrpcObj();
    Json_RestartNotify_Param *pJsonData = new Json_RestartNotify_Param();
    
    as_presence_gettime_YMDHMS(sztime_ymdhms);
    pJsonObj->pJsonrpc          = JSONRPC_V;
    pJsonObj->pMethod           = MSGTYPE_RESTAT_STR;
    pJsonObj->UserData.pData    = pJsonData;
    pJsonData->pDate            = sztime_ymdhms;
    pJsonData->pSbcId           = pSbcid;
    
    MsgJsonString msgJsonString(pJsonObj) ;
    pMsgBody = msgJsonString.GetJsonString();
    if(pMsgBody)
    {
        as_presence_send_MQmsg_seatgwbroadcast(pMsgBody);
        nRet = SWITCH_STATUS_SUCCESS;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s EncodeMsgBody error\n", __FUNCTION__);        
        nRet = SWITCH_STATUS_FALSE;
    }
    return nRet;

}

/*****************************************************************************
  �� �� ��  : SendMQ_OldSeatgw_SubscribeInvalidNotify
  ��������  ���Ͷ���ʧЧ��oldseatgw
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t SendMQ_OldSeatgw_SubscribeInvalidNotify(const char *pSbcid, const char *pUri, const char *pOldSeatgwid, const char *pOldAccount, const char *pNewSeatgwid, const char *pNewAccount)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    const char *pMsgBody = NULL; 
    char sztime_ymdhms[TIME_STR_LEN +1] = {0};

    JsonrpcObj * pJsonObj = new JsonrpcObj();
    Json_SubInvalidNotify_Param *pJsonParam = new Json_SubInvalidNotify_Param();
    Json_List<Json_SubInvalidNotify_ListNode> *pJson_OldList = new Json_List<Json_SubInvalidNotify_ListNode>();
    Json_List<Json_SubInvalidNotify_ListNode> *pJson_NewList = new Json_List<Json_SubInvalidNotify_ListNode>();
    Json_SubInvalidNotify_ListNode *pOldListNodes = new Json_SubInvalidNotify_ListNode[1]();
    Json_SubInvalidNotify_ListNode *pNewListNodes = new Json_SubInvalidNotify_ListNode[1]();

    as_presence_gettime_YMDHMS(sztime_ymdhms);
    
    pJsonObj->pJsonrpc = JSONRPC_V;
    pJsonObj->pMethod = MSGTYPE_SUBSCRIBEINVAILD_STR;
    pJsonObj->UserData.pParam   = pJsonParam;

    pJsonParam->pDate           = sztime_ymdhms;
    pJsonParam->pOldList        = pJson_OldList;
    pJsonParam->pNewList        = pJson_NewList;

    pJson_OldList->nListCount   = 1;
    pJson_OldList->pObjListNodes = pOldListNodes;
    pJson_NewList->nListCount   = 1;
    pJson_NewList->pObjListNodes = pNewListNodes;
    
    pOldListNodes[0].pAccount =  pOldAccount;
    pOldListNodes[0].pSeatgwId =  pOldSeatgwid;
    pOldListNodes[0].pUri =  pUri;
    pOldListNodes[0].pSbcId =  pSbcid;

    pNewListNodes[0].pAccount =  pNewAccount;
    pNewListNodes[0].pSeatgwId =  pNewSeatgwid;
    pNewListNodes[0].pUri =  pUri;
    pNewListNodes[0].pSbcId =  pSbcid;
 
    MsgJsonString msgJsonString(pJsonObj) ;
    pMsgBody = msgJsonString.GetJsonString();
    if(pMsgBody)
    {
        as_presence_send_MQmsg_seatgw(pOldSeatgwid, pMsgBody);
        nRet = SWITCH_STATUS_SUCCESS;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
             "%s EncodeMsgBody error\n", __FUNCTION__);    
        nRet = SWITCH_STATUS_FALSE;
    }

    return nRet;
}

/*****************************************************************************
  �� �� ��  : SendMQ_Seatgw_Response
  ��������  ����seatgw��Ӧ��Ϣ
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t SendMQ_Seatgw_Response(const char * pId, const char *pSeatgwid, const char *pType, const char *pReason, list<string> *pListSuccess, list<string> *pListFailure)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    const char *pMsgBody = NULL;
    char sztime_ymdhms[TIME_STR_LEN +1] = {0};
    JsonrpcObj * pJsonObj = new JsonrpcObj();
    Json_Response_Param *pJsonData = new Json_Response_Param();
    
    as_presence_gettime_YMDHMS(sztime_ymdhms);
 
    pJsonObj->pJsonrpc          = JSONRPC_V;
    pJsonObj->pResult           = pType;
    pJsonObj->pId               = pId;
    pJsonObj->UserData.pData    = pJsonData;
    pJsonData->pDate            = sztime_ymdhms;
    pJsonData->pReason          = pReason ? pReason : "";
    pJsonData->pListSuccess     = pListSuccess;
    pJsonData->pListFailure     = pListFailure;

    MsgJsonString msgJsonString(pJsonObj) ;
    pMsgBody = msgJsonString.GetJsonString();
    if(pMsgBody)
    {
        as_presence_send_MQmsg_seatgw(pSeatgwid, pMsgBody); 
        nRet = SWITCH_STATUS_SUCCESS;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
             "%s EncodeMsgBody error\n", __FUNCTION__);    
        nRet = SWITCH_STATUS_FALSE;
    }
    
    return nRet;
    
}

static switch_status_t SendMQ_Web_Response(const char *pId , const char *pType, const char *pReason, list<string> *pListSuccess, list<string> *pListFailure)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    const char *pMsgBody = NULL;
    char sztime_ymdhms[TIME_STR_LEN +1] = {0};
    JsonrpcObj * pJsonObj = new JsonrpcObj();
    Json_Response_Param *pJsonData = new Json_Response_Param();
    
    as_presence_gettime_YMDHMS(sztime_ymdhms);
 
    pJsonObj->pJsonrpc          = JSONRPC_V;
    pJsonObj->pResult           = pType;
    pJsonObj->pId               = pId;
    pJsonObj->UserData.pData    = pJsonData;
    pJsonData->pDate            = sztime_ymdhms;
    pJsonData->pReason          = pReason ? pReason : "";
    pJsonData->pListSuccess     = pListSuccess;
    pJsonData->pListFailure     = pListFailure;

    MsgJsonString msgJsonString(pJsonObj) ;
    pMsgBody = msgJsonString.GetJsonString();
    if(pMsgBody)
    {
        as_presence_send_MQmsg_web(pMsgBody); 
        nRet = SWITCH_STATUS_SUCCESS;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
             "%s EncodeMsgBody error\n", __FUNCTION__);     
        
        nRet = SWITCH_STATUS_FALSE;
    }
    
    return nRet;
    
}

/*****************************************************************************
  �� �� ��  : SendMQ_Seatgw_StateNotify
  ��������  ����״̬֪ͨ
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/

static switch_status_t SendMQ_Seatgw_StateNotify(const char *pSbcid, const char *pUri, const char *pState)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    const char *pMsgBody = NULL; 
    char szSeatgwId[MAX_SEATGWID_LEN + 1] = {0};
    char szAccount[MAX_ACCOUNT_LEN + 1] = {0};

    if(-1 == g_cSubscriptitonRelationManagement->GetRelation(pUri, szSeatgwId, MAX_SEATGWID_LEN, szAccount, MAX_ACCOUNT_LEN))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
                 "SendMQ_Seatgw_StateNotify GetRelation uri:%s  havent subscribe relation \n", pUri );
        return SWITCH_STATUS_SUCCESS;
    }

    char sztime_ymdhms[TIME_STR_LEN +1] = {0};

    JsonrpcObj * pJsonObj = new JsonrpcObj();
    Json_StateNotify_Param *pJsonParam = new Json_StateNotify_Param();
    Json_List<Json_StateNotify_ListNode> *pJson_List = new Json_List<Json_StateNotify_ListNode>();
    Json_StateNotify_ListNode *pListNodes = new Json_StateNotify_ListNode[1]();
        
    as_presence_gettime_YMDHMS(sztime_ymdhms);

    pJsonObj->pJsonrpc          = JSONRPC_V;
    pJsonObj->pMethod           = MSGTYPE_STATE_STR;
    pJsonObj->UserData.pParam   = pJsonParam;
    
    pJsonParam->pDate           = sztime_ymdhms;
    pJsonParam->pObjList        = pJson_List;

    pJson_List->nListCount      = 1;
    pJson_List->pObjListNodes   = pListNodes;
    pListNodes[0].pAccount      = szAccount;
    pListNodes[0].pSeatgwId     = szSeatgwId;
    pListNodes[0].pUri          = pUri;
    pListNodes[0].pState        = pState;
    pListNodes[0].pSbcId        = pSbcid;

    MsgJsonString msgJsonString(pJsonObj) ;
    pMsgBody = msgJsonString.GetJsonString();
    if(pMsgBody)
    {
        as_presence_send_MQmsg_seatgw(szSeatgwId, pMsgBody);
        nRet = SWITCH_STATUS_SUCCESS;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s EncodeMsgBody error\n", __FUNCTION__);        
        nRet = SWITCH_STATUS_FALSE;
    }

    return nRet;
}



/*****************************************************************************
  �� �� ��  : Event_A_RegModify_Request
  ��������  �Ǽ��û���Ϣ
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t Event_A_RegModify_Request(Json_RegModifyReq_ListNode *pStMsgObjListNode, _Out_ string &uriOutString)
{
    const char *pNum = pStMsgObjListNode->pNum;
    const char *pDomain = pStMsgObjListNode->pDomain;
    const char *pIp = pStMsgObjListNode->pIp;
    const char *pPort = pStMsgObjListNode->pPort;
    const char *pPWD = pStMsgObjListNode->pPwd;
    const char *pCodec = pStMsgObjListNode->pCodec;
    
    char szURI[MAX_URI_LEN + 1] = {0};
    char szSysCmd[REGISTER_SHELL_CMD_LEN + 1] = {0}; 
    
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    
    uriOutString = "";
    if(NULL == pNum || NULL == pDomain) 
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "Event_A_RegModify_Request pNum = %p, pDomain=%p\n", pNum, pDomain);
        return SWITCH_STATUS_FALSE;
    }
    
    switch_snprintf(szURI, MAX_URI_LEN, "%s@%s",pNum, pDomain);

    uriOutString = szURI;

    if(strncmp(pIp, sbcinfo.szIp, SBCIP_LEN) != 0)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "Event_A_RegModify_Request ip:%s is not local ip\n", pIp);
        return SWITCH_STATUS_FALSE;
    }

    switch_snprintf(szSysCmd, REGISTER_SHELL_CMD_LEN,  "%s reg_modify %s %s %s %s %s", REGISTER_SHELL_FILE, pNum, pDomain, pIp, pPort, pPWD);
    int nShellValue = system(szSysCmd);
    if(nShellValue == 0)
    {
        nRet = SWITCH_STATUS_SUCCESS;
        if (-1 == g_cTerminalManagement->ModifyTerminalState(szURI))
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "Event_A_RegModify_Request szSysCmd = %s\n", szSysCmd);
            nRet= SWITCH_STATUS_FALSE;
        }        
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "Event_A_RegModify_Request szSysCmd = %s\n", szSysCmd);
        nRet= SWITCH_STATUS_FALSE;
    }
  
    return nRet;
        
}


/*****************************************************************************
  �� �� ��  : Event_A_RegDel_Request
  ��������  ɾ���û���Ϣ
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t Event_A_RegDel_Request(Json_RegDelReq_ListNode *pStMsgObjListNode, _Out_ string &uriOutString)
{
    const char *pNum = pStMsgObjListNode->pNum;
    const char *pDomain = pStMsgObjListNode->pDomain;
    char szURI[MAX_URI_LEN + 1] = {0};
    char szSysCmd[REGISTER_SHELL_CMD_LEN + 1] = {0}; 
    
    switch_status_t nRet = SWITCH_STATUS_FALSE;

    uriOutString = "";
    if(NULL == pNum || NULL == pDomain) 
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "Event_A_RegDel_Request pNum = %p, pDomain=%p\n", pNum, pDomain);
        return SWITCH_STATUS_FALSE;
    }
    
    switch_snprintf(szURI, MAX_URI_LEN, "%s@%s",pNum, pDomain);

    uriOutString = szURI;

    switch_snprintf(szSysCmd, REGISTER_SHELL_CMD_LEN,  "%s reg_del %s %s", REGISTER_SHELL_FILE, pNum, pDomain);
    int nShellValue = system(szSysCmd);
    if(nShellValue == 0)
    {
        nRet = SWITCH_STATUS_SUCCESS;
        g_cTerminalManagement->DelTerminalState(szURI);
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "Event_A_RegDel_Request szSysCmd = %s\n", szSysCmd);
        nRet = SWITCH_STATUS_FALSE;
    }
    
    return nRet;
        
}

static switch_status_t Event_A_Subscribe_Request(Json_SubReq_ListNode *pStMsgObjListNode, _Out_ string &uriOutString)
{
    char szSeatgwid_mem[MAX_SEATGWID_LEN + 1] = {0};
    char szAccount_mem[MAX_ACCOUNT_LEN + 1] = {0};
    int terminalstate = -1 ;
    const char *pAccount = pStMsgObjListNode->pAccount;
    const char *pSeatgwid = pStMsgObjListNode->pSeatgwId;
    const char *pUri = pStMsgObjListNode->pUri;

    uriOutString = "";
    if(NULL == pUri || NULL == pAccount || NULL == pSeatgwid) 
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "Event_A_Subscribe_Request pUri = %p, pAccount=%p, pSeatgwid=%p\n", pUri, pAccount, pSeatgwid);
        return SWITCH_STATUS_FALSE;
    }
     
    uriOutString = pUri;
    
    // 1. uri�Ƿ��ڱ���ע��
    terminalstate = g_cTerminalManagement->GetTerminalState(pUri);
    if(-1 == terminalstate)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "Event_A_Subscribe_Request %s ,haven't this terminal\n", pUri);
        return SWITCH_STATUS_FALSE;
    }

    //���ڶ��Ĺ�ϵ
    if(0 == g_cSubscriptitonRelationManagement->GetRelation(pUri, szSeatgwid_mem, MAX_SEATGWID_LEN, szAccount_mem, MAX_ACCOUNT_LEN))
    {
        if((strcmp(szSeatgwid_mem, pSeatgwid) != 0) || (strcmp(szAccount_mem, pAccount) != 0) )
        {        

            //֪ͨԭ����ϵʧЧ
            SendMQ_OldSeatgw_SubscribeInvalidNotify(sbcinfo.szSbcId, pUri, szSeatgwid_mem, szAccount_mem, pSeatgwid, pAccount);
           
            // ���¶��Ĺ�ϵ
            g_cSubscriptitonRelationManagement->UpdateRelation(pUri, pSeatgwid, pAccount);
        }
    }
    else
    {
        g_cSubscriptitonRelationManagement->AddRelation(pUri, pSeatgwid, pAccount);
    }
    return SWITCH_STATUS_SUCCESS;
    
}

static switch_status_t Event_A_Unsubscribe_Request(Json_UnsubReq_ListNode *pStMsgObjListNode, _Out_ string &uriOutString)
{
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    const char *pAccount = pStMsgObjListNode->pAccount;
    const char *pSeatgwid = pStMsgObjListNode->pSeatgwId;
    const char *pUri = pStMsgObjListNode->pUri;

    uriOutString = "";
    if(NULL == pUri || NULL == pAccount || NULL == pSeatgwid) 
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "Event_A_Unsubscribe_Request pUri = %p, pAccount=%p, pSeatgwid=%p\n", pUri, pAccount, pSeatgwid);
        return SWITCH_STATUS_FALSE;
    }
    uriOutString = pUri;
    
    //��鶩�Ĺ�ϵ����ɾ����  
    if(0 == g_cSubscriptitonRelationManagement->DelRelation(pUri, pSeatgwid, pAccount))
    {
        nRet = SWITCH_STATUS_SUCCESS;
    }
    else
    {
        nRet = SWITCH_STATUS_FALSE;
    }
    return nRet;
    
}

/*****************************************************************************
  �� �� ��  : MQmsg_Event_Subscribe
  ��������  �����¼��Ĵ�������
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/

static switch_status_t MQmsg_Event_Subscribe(JsonrpcObj *pJsonrpcMsg)
{  
    string uriString = "";
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_status_t nReqValue = SWITCH_STATUS_FALSE;
    list<string> listSuccess;
    list<string> listFailure;
    
    Json_SubReq_Param * pJson_Param =  (Json_SubReq_Param *)pJsonrpcMsg->UserData.pParam;
    Json_List<Json_SubReq_ListNode> *pJson_List = (Json_List<Json_SubReq_ListNode> *)pJson_Param->pObjList;
    Json_SubReq_ListNode *pJson_ListNode = pJson_List->pObjListNodes;
    
    const char *pSeatgwid   = pJson_ListNode[0].pSeatgwId;
    int nUserTotal          = pJson_List->nListCount ;
    int i;
    int terminalstate = -1 ;

    nRet = SWITCH_STATUS_SUCCESS;
    for(i = 0 ; i < nUserTotal ; i++)
    {
        nReqValue = Event_A_Subscribe_Request(&(pJson_ListNode[i]), uriString);
        if(SWITCH_STATUS_SUCCESS == nReqValue )
        {
            if("" != uriString)
            {
                listSuccess.push_back(uriString);
            }
        }
        else
        {
            nRet = SWITCH_STATUS_FALSE;
            if("" != uriString)
            {
                listFailure.push_back(uriString);
            }
        }
    }
        
    SendMQ_Seatgw_Response(pJsonrpcMsg->pId, pSeatgwid, MSGTYPE_SUBSCRIBE_STR, NULL, &listSuccess, &listFailure);
    
    // ����״̬����Ӧ��seatgw
    list<string>::iterator it=listSuccess.begin();
    for(; it != listSuccess.end(); it++)
    {
        terminalstate = g_cTerminalManagement->GetTerminalState(it->c_str());
        if(-1 != terminalstate)
        {
            SendMQ_Seatgw_StateNotify(sbcinfo.szSbcId, it->c_str(), g_cTerminalStateTranscation->GetStateString(terminalstate));
        }
    }
    return SWITCH_STATUS_SUCCESS;
    
}

/*****************************************************************************
  �� �� ��  : MQmsg_Event_Unsubscribe
  ��������  ȡ�������¼��Ĵ�������
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t MQmsg_Event_Unsubscribe(JsonrpcObj *pJsonrpcMsg)
{
    string uriString = "";
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_status_t nReqValue = SWITCH_STATUS_FALSE;
    list<string> listSuccess;
    list<string> listFailure;

    Json_SubReq_Param * pJson_Param =  (Json_SubReq_Param *)pJsonrpcMsg->UserData.pParam;    
    Json_List<Json_UnsubReq_ListNode> *pJson_List = (Json_List<Json_UnsubReq_ListNode> *)pJson_Param->pObjList;
    Json_UnsubReq_ListNode *pJson_ListNode = pJson_List->pObjListNodes;
    
    int nUserTotal = pJson_List->nListCount ;
    const char *pSeatgwid   = pJson_ListNode[0].pSeatgwId;
    int i;

    nRet = SWITCH_STATUS_SUCCESS;
    for(i = 0 ; i < nUserTotal ; i++)
    {
        nReqValue = Event_A_Unsubscribe_Request(&(pJson_ListNode[i]), uriString);
        if(SWITCH_STATUS_SUCCESS == nReqValue )
        {
            if("" != uriString)
            {
                listSuccess.push_back(uriString);
            }
        }
        else
        {
            nRet = SWITCH_STATUS_FALSE;
            if("" != uriString)
            {
                listFailure.push_back(uriString);
            }
        }
    }

    SendMQ_Seatgw_Response(pJsonrpcMsg->pId, pSeatgwid, MSGTYPE_SUBSCRIBE_STR, NULL, &listSuccess, &listFailure);
    return SWITCH_STATUS_SUCCESS;
    
}

/*****************************************************************************
  �� �� ��  : MQmsg_Event_RegModify
  ��������  �����¼��Ĵ�������
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/

static switch_status_t MQmsg_Event_RegModify(JsonrpcObj *pJsonrpcMsg)
{    
    string uriString = "";
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_status_t nReqValue = SWITCH_STATUS_FALSE;
    list<string> listSuccess;
    list<string> listFailure;

    Json_RegModifyReq_Param * pJson_Param =  (Json_RegModifyReq_Param *)pJsonrpcMsg->UserData.pParam;    
    Json_List<Json_RegModifyReq_ListNode> *pJson_List = (Json_List<Json_RegModifyReq_ListNode> *)pJson_Param->pObjList;
    Json_RegModifyReq_ListNode *pJson_ListNode = pJson_List->pObjListNodes;
    
    int nUserTotal = pJson_List->nListCount ;
    int i;

    nRet = SWITCH_STATUS_SUCCESS;
    for(i = 0 ; i < nUserTotal ; i++)
    {
        nReqValue = Event_A_RegModify_Request(&(pJson_ListNode[i]), uriString);
        if(SWITCH_STATUS_SUCCESS == nReqValue )
        {
            if("" != uriString)
            {
                listSuccess.push_back(uriString);
            }
        }
        else
        {
            nRet = SWITCH_STATUS_FALSE;
            if("" != uriString)
            {
                listFailure.push_back(uriString);
            }
        }
    }

    SendMQ_Web_Response(pJsonrpcMsg->pId, MSGTYPE_REG_MODIFY_STR, NULL, &listSuccess, &listFailure);
    return SWITCH_STATUS_SUCCESS;
    
}


/*****************************************************************************
  �� �� ��  : MQmsg_Event_RegDel
  ��������  �����¼��Ĵ�������
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t MQmsg_Event_RegDel(JsonrpcObj *pJsonrpcMsg)
{
    string uriString = "";
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_status_t nReqValue = SWITCH_STATUS_FALSE;
    list<string> listSuccess;
    list<string> listFailure;
    
    
    Json_RegDelReq_Param * pJson_Param =  (Json_RegDelReq_Param *)pJsonrpcMsg->UserData.pParam;    
    Json_List<Json_RegDelReq_ListNode> *pJson_List = (Json_List<Json_RegDelReq_ListNode> *)pJson_Param->pObjList;
    Json_RegDelReq_ListNode *pJson_ListNode = pJson_List->pObjListNodes;
    
    int nUserTotal = pJson_List->nListCount ;
    int i;
    
    nRet = SWITCH_STATUS_SUCCESS;
    for(i = 0 ; i < nUserTotal ; i++)
    {
        nReqValue = Event_A_RegDel_Request(&(pJson_ListNode[i]), uriString);
        if(SWITCH_STATUS_SUCCESS == nReqValue )
        {
            if("" != uriString)
            {
                listSuccess.push_back(uriString);
            }
        }
        else
        {
            nRet = SWITCH_STATUS_FALSE;
            if("" != uriString)
            {
                listFailure.push_back(uriString);
            }
        }
    }
    
    SendMQ_Web_Response(pJsonrpcMsg->pId, MSGTYPE_REG_DEL_STR, NULL, &listSuccess, &listFailure);
    return SWITCH_STATUS_SUCCESS;
    
}

static switch_status_t PresenceEvent_RecvType_MQmsg(switch_event_t *event)
{
    const char *pMsgBody = NULL;
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    MsgJsonString msgJsonString;
    int nType = 0;
    
    pMsgBody = switch_event_get_header(event, MQMSG_MSGBODY_STR);
    if(NULL == pMsgBody)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "PresenceEvent_RecvType_MQmsg switch_event_get_header failed\n");
        return SWITCH_STATUS_FALSE;  
    }
    
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
             "PresenceEvent_RecvType_MQmsg pMsgBody = %s\n",pMsgBody);
    nRet = msgJsonString.JsonStringParse(pMsgBody);
    if(SWITCH_STATUS_FALSE == nRet)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "PresenceEvent_RecvType_MQmsg DecodeSbcMethodMsgBody failed\n");
        return SWITCH_STATUS_FALSE;
    }

    nType = msgJsonString.pMsgObj->msgType;
    switch(nType)
    {
        case MSGTYPE_SUBSCRIBE:
            nRet = MQmsg_Event_Subscribe(msgJsonString.pMsgObj);
            break;
            
        case MSGTYPE_UNSUBSCRIBE:
            nRet = MQmsg_Event_Unsubscribe(msgJsonString.pMsgObj);
            break;

        case MSGTYPE_REG_MODIFY:
            nRet = MQmsg_Event_RegModify(msgJsonString.pMsgObj);
            break;

        case MSGTYPE_REG_DEL:
            nRet = MQmsg_Event_RegDel(msgJsonString.pMsgObj);
            break;
            
        default:
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
                "PresenceEvent_RecvType_MQmsg nType = %d failed\n", nType);
            nRet = SWITCH_STATUS_FALSE;
            break;
    }

    return nRet;
}

static switch_status_t PresenceEvent_SubType_MQmsg(switch_event_t *event)
{
    const char *pQueuname = NULL;
    const char *pResult = NULL;
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    
    pQueuname = switch_event_get_header(event, MQMSG_QUEUENAME_STR);
    if(NULL == pQueuname)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "PresenceEvent_SubType_MQmsg switch_event_get_header failed\n");
        return SWITCH_STATUS_FALSE;  
    }

    pResult = switch_event_get_header(event, MQMSG_RESULT_STR);
    if(NULL == pResult)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "PresenceEvent_SubType_MQmsg switch_event_get_header failed\n");
        return SWITCH_STATUS_FALSE;  
    }

    if(pResult[0] == '1')
    {
        return SWITCH_STATUS_FALSE;
    }

    if(strcmp(pQueuname, sbcinfo.szSbcQueueName) == 0)
    {
        sbcinfo.nSbcQueueSubFlag = 1;
    }
    else if(strcmp(pQueuname, sbcinfo.szSbcWebQueueName) == 0)
    {
        sbcinfo.nSbcWebQueueSubFlag = 1;
    } 

    return SWITCH_STATUS_SUCCESS;

    
}

static switch_status_t PresenceEvent_PubType_MQmsg(switch_event_t *event)
{
    return SWITCH_STATUS_SUCCESS;
}

/*****************************************************************************
  �� �� ��  : MQmsg_Event_RegDel
  ��������  rabbitmq �¼��Ĵ�������
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/

static switch_status_t PresenceEvent_MQmsg(switch_event_t *event)
{

    const char *pType = NULL;
        
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    
    int nMQMsgType = -1;

    pType = switch_event_get_header(event, MQMSG_TYPE_STR);
    if(NULL == pType)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
             "PresenceEvent_MQmsg switch_event_get_header failed\n");
        return SWITCH_STATUS_FALSE;  
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, 
             "PresenceEvent_MQmsg  pType = %s\n",pType);
    nMQMsgType = MQTypeInt(pType);
    switch(nMQMsgType)
    {
        case MQTYPE_SUB:
            nRet = PresenceEvent_SubType_MQmsg(event);
            break;
        case MQTYPE_PUB:
            nRet = PresenceEvent_PubType_MQmsg(event);
            break;
        case MQTYPE_RECV:
            nRet = PresenceEvent_RecvType_MQmsg(event);
        default:
            nRet = SWITCH_STATUS_FALSE;
    }

    return nRet;
    
    
}


/*****************************************************************************
  �� �� ��  : PresenceEvent_PresenceIn
  ��������  presence_in  �¼��Ĵ�������
  �������  :
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
static switch_status_t PresenceEvent_PresenceIn(switch_event_t *event)
{
    const char *pStatus = NULL;
    const char *pUri = NULL;
    const char *pChannelState = NULL;
    const char *pNextStatus = NULL;
    switch_status_t nRet = SWITCH_STATUS_FALSE;
    
    char szSeatgwId[MAX_SEATGWID_LEN + 1] = {0};
    char szAccount[MAX_ACCOUNT_LEN + 1] = {0};
    
    int nSubscribeEvent = ESL_SUBSCRIBE_EVENT_REGISTERED;
    int nCallingState = ESL_CALLING_STATE_HANGUP;
   
    int nCurTerminalState = TERMINAL_STATE_NULL ;
    int nNextTerminalState = TERMINAL_STATE_NULL;
      
    pUri = switch_event_get_header(event, "from");
    if(NULL == pUri)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
                "from is null"); 
        return SWITCH_STATUS_FALSE;
    }
    
    pStatus = switch_event_get_header(event, "status");
    if(pStatus)
    {
        if(0 == strcmp(pStatus, "Registered"))
        {
            nSubscribeEvent = ESL_SUBSCRIBE_EVENT_REGISTERED;
        }
        else if(0 == strcmp(pStatus, "Unregistered"))
        {
            nSubscribeEvent = ESL_SUBSCRIBE_EVENT_UNREGISTERED;
        }
        else if(0 == strcmp(pStatus, "CS_HANGUP"))
        {
            nSubscribeEvent = ESL_SUBSCRIBE_EVENT_HANGUP;
        }
        else
        {
            nSubscribeEvent = ESL_SUBSCRIBE_EVENT_OTHER;
        }
    }
    else
    {
       switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
                "status is null"); 
       return SWITCH_STATUS_FALSE;
    }

    pChannelState = switch_event_get_header(event, "Channel-State");
    if(pChannelState)
    {
        if(0 == strcmp(pChannelState, "CS_HANGUP"))
        {
            nCallingState = ESL_CALLING_STATE_HANGUP;
        }
        else
        {
            nCallingState = ESL_CALLING_STATE_OTHER;
        }
    }
    else
    {
        nCallingState = ESL_CALLING_STATE_NULL;
    }

    nCurTerminalState = g_cTerminalManagement->GetTerminalState(pUri); 
   
    nNextTerminalState = g_cTerminalStateTranscation->Transaction(nSubscribeEvent, nCallingState, nCurTerminalState);

    if(nCurTerminalState == nNextTerminalState)
    {
        nRet= SWITCH_STATUS_SUCCESS;
    }
    else
    {
        pNextStatus = g_cTerminalStateTranscation->GetStateString(nNextTerminalState);
        if(NULL != pNextStatus)
        {
            // д��redis
            nRet = as_presence_redis_set_terminal_state(pUri, pNextStatus);
            if(SWITCH_STATUS_SUCCESS != nRet)
            {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
                            "as_presence_redis_set_terminal_state error\n");
               
            }

            // �����ڴ�״̬
            g_cTerminalManagement->UpdateTerminalState(pUri, (int)nNextTerminalState);
            nRet = SendMQ_Seatgw_StateNotify(sbcinfo.szSbcId, pUri, pNextStatus);
            
        }
        else
        {
            nRet= SWITCH_STATUS_FALSE;
        }
    }
    return nRet;
    
}

/****************************************
*�� �� �� : as_presence_presencein_event_handler
*����˵�� : �¼��󶨻ص�����
*��    �� : event�¼�
*��    �� : ��
*�� �� ֵ : void����
****************************************/
void as_presence_presencein_event_handler(switch_event_t *event)
{
    if(NULL == event)
    {
        return;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
          "as_presence_presencein_event_handler()\n");   

    switch(event->event_id)
    {
        case SWITCH_EVENT_PRESENCE_IN:
             PresenceEvent_PresenceIn(event);
             break;                 
        default:
            break;
    }
}


/****************************************
*�� �� �� : as_presence_MQmsg_event_handler
*����˵�� : �¼��󶨻ص�����
*��    �� : event�¼�
*��    �� : ��
*�� �� ֵ : void����
****************************************/

void as_presence_MQmsg_event_handler(switch_event_t *event)
{
    if(NULL == event)
    {
        return;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
          "as_presence_MQmsg_event_handler()\n");   

    if (event->subclass_name && (!strcmp(event->subclass_name, sbcinfo.szSeatGwEvent) || !strcmp(event->subclass_name, sbcinfo.szWebEvent)))
    {
        PresenceEvent_MQmsg(event);
    }
 
}

