#ifndef __MOD_AS_PRESENCE_JSONRPC_H__
#define __MOD_AS_PRESENCE_JSONRPC_H__

#include <switch.h>
#include <switch_json.h>
#include <string>
#include <list>
using namespace std;

#define JSONRPC_V       "2.0"

#define MSGMETHOD_REQUEST_STR           "request"
#define MSGMETHOD_RESPONSE_STR          "response"
#define MSGMETHOD_NOTIFICATION_STR      "notification"

#define FAILED_STR                      "failed"
#define SUCCESSFUL_STR                  "successful"



#define JSON_JSONRPC_KEY            "jsonrpc"

#define JSON_METHOD_KEY            "method"
#define JSON_PARAMS_KEY             "params"

#define JSON_DATA_KEY             "data"
#define JSON_OBJLIST_KEY          "obj_list"

#define JSON_SUCCESSLIST_KEY     "success_list"
#define JSON_FAILURELIST_KEY     "failure_list"



#define JSON_ACCOUNT_KEY    "account"
#define JSON_SEATGWID_KEY   "seatgw_id"
#define JSON_URI_KEY        "uri"
#define JSON_TYPE_KEY       "type"
#define JSON_RESULT_KEY     "result"
#define JSON_REASON_KEY     "reason"
#define JSON_NUM_KEY        "num"
#define JSON_DOMAIN_KEY     "domain"
#define JSON_IP_KEY         "ip"
#define JSON_PORT_KEY       "port"
#define JSON_PWD_KEY        "pwd"
#define JSON_CODEC_KEY      "codec"
#define JSON_DATE_KEY       "date"
#define JSON_SBCID_KEY      "sbc_id"
#define JSON_STATE_KEY      "state"
#define JSON_ID_KEY         "id"
#define JSON_OLDLIST_KEY    "old_list"    
#define JSON_NEWLIST_KEY    "new_list" 

#define GETJSONVALUE_RETURN(json, key, key_value, error_return) \
{\
    key_value = cJSON_GetObjectCstr(json, key);\
    if((NULL == key_value) && error_return)\
    {\
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, \
             "cJSON_GetObjectCstr %s is NULL \n", key);\
        return SWITCH_STATUS_FALSE; \
    }\
}

#define GETJSONOBJ_RETURN(json, key, subJson, error_return) \
{\
    subJson = cJSON_GetObjectItem(json, key);\
    if((NULL == subJson) && error_return)\
    {\
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, \
             "cJSON_GetObjectCstr %s is NULL \n", key);\
        return SWITCH_STATUS_FALSE; \
    }\
}
#if 1
/*��Щ�඼��jsonrpc�����ݳ�Ա�Ľṹ�壬��cJSON ���л�ȡ��Ա��
    �����ݳ�Ա���ΪcJSON ��ʽ
*/
class JsonBase;  //

// ��Բ�ͬ��Ϣ���в�ͬ��objlist ���ݣ�ÿ��list ���ж����һ��listnode
class Json_SubReq_ListNode;
typedef Json_SubReq_ListNode Json_UnsubReq_ListNode; // ���ĺ�ȡ�����ĵ�listNode ��Ϣ�ṹ��һ���ģ����Ծ���typedef

class Json_RegModifyReq_ListNode;
class Json_RegDelReq_ListNode;
class Json_StateNotify_ListNode;
class Json_SubInvalidNotify_ListNode;

template <class NodeType> 
class Json_List;

// jsonrpc ��param ��data ���ݳ�Ա
class   Json_Req_Param;

typedef Json_Req_Param Json_SubReq_Param;
typedef Json_Req_Param Json_UnsubReq_Param;
typedef Json_Req_Param Json_RegModifyReq_Param;
typedef Json_Req_Param Json_RegDelReq_Param;
typedef Json_Req_Param Json_StateNotify_Param;


class Json_SubInvalidNotify_Param;
class Json_RestartNotify_Param;
class Json_Response_Param;

// JsonrpcObj ��
class JsonrpcObj;

class MsgJsonString;
#endif

#define JSON 1

class JsonBase
{
public:
   virtual ~JsonBase();
   virtual cJSON *Json();
   virtual switch_status_t DecodeJson(cJSON *pJson);
};



class Json_SubReq_ListNode:public JsonBase
{
public:
    const char *pAccount;
    const char *pSeatgwId;
    const char *pUri;
    
public:
    Json_SubReq_ListNode();
    virtual switch_status_t DecodeJson(cJSON *pJson);
};
   
class Json_RegModifyReq_ListNode:public JsonBase
{
public:
    const char *pNum;
    const char *pDomain;
    const char *pIp;
    const char *pPort;
    const char *pPwd;
    const char *pCodec;
    
public:
    Json_RegModifyReq_ListNode();
    virtual switch_status_t DecodeJson(cJSON *pJson);
};
   
class Json_RegDelReq_ListNode:public JsonBase
{
public:
    const char *pNum;
    const char *pDomain;

public:    
    Json_RegDelReq_ListNode();
    virtual switch_status_t DecodeJson(cJSON *pJson);
};

class Json_StateNotify_ListNode:public JsonBase
{
public:
    const char *pAccount;
    const char *pSeatgwId;
    const char *pState;
    const char *pUri;
    const char *pSbcId;

public:
    Json_StateNotify_ListNode();
    virtual cJSON *Json();
    
};

class Json_SubInvalidNotify_ListNode:public JsonBase
{
public:
    const char *pAccount;
    const char *pSeatgwId;
    const char *pUri;
    const char *pSbcId;

public:    
    Json_SubInvalidNotify_ListNode();
    virtual cJSON *Json();
    
};

template <class NodeType> 
class Json_List:public JsonBase
{
public:
    int nListCount;
    NodeType *pObjListNodes;
public:
    Json_List();
    virtual ~Json_List();    
    virtual cJSON *Json();
    virtual switch_status_t DecodeJson(cJSON *pJson);

};

#if JSON
class Json_Req_Param :public JsonBase
{
public:
    const char *pDate;
    JsonBase *pObjList;
public:

    Json_Req_Param();
    Json_Req_Param(int nMsgType);
    virtual ~Json_Req_Param();   
    virtual cJSON *Json();
    virtual switch_status_t DecodeJson(cJSON *pJson);
      
};

class Json_SubInvalidNotify_Param :public JsonBase
{
public:
    const char *pDate;
    JsonBase *pOldList;
    JsonBase *pNewList;
public:
    Json_SubInvalidNotify_Param(JsonBase *pOldList_ = NULL, JsonBase *pNewList_ = NULL);
    virtual ~Json_SubInvalidNotify_Param();
    virtual cJSON *Json();
};


class Json_RestartNotify_Param:public JsonBase
{
public:
    const char *pDate;
    const char *pSbcId;
public:
    Json_RestartNotify_Param();
    virtual cJSON *Json();

};

class Json_Response_Param:public JsonBase
{
public:
    const char      *pDate;
    const char      *pReason;
    list<string>    *pListSuccess;
    list<string>    *pListFailure;
public:
    Json_Response_Param();
    virtual cJSON *Json();   
};

enum JsonType
{
    JsonType_method =0,
    JsonType_result,
    JsonType_invalid,
};


class JsonrpcObj:public JsonBase
{
public: 

    
    JsonType nJsonType;
    int msgType;
    const char *pJsonrpc;
    const char *pId;
  
    const char *pMethod;
    const char *pResult;
    
    union 
    {
        JsonBase *pParam;  // "uoType == method " , Json_SubReq_Param,Json_UnsubReq_Param,Json_RegModifyReq_Param,Json_RegDelReq_Param,Json_StateNotify_Param,Json_SubInvalidNotify_Param,Json_RestartNotify_Param ... etc param type
        JsonBase *pData;  // Json_Response_Param , ..."uoType == JsonType_result " ,data param
    }UserData;
//    JsonBase *pSubParam;
public:
    JsonrpcObj();
    JsonrpcObj(int nJsonType, int nMsgtype);
    virtual ~JsonrpcObj();
    virtual cJSON *Json();
    virtual switch_status_t DecodeJson(cJSON *pJson);       
};

class MsgJsonString
{
public:
    cJSON *pMsgJson;
    JsonrpcObj *pMsgObj;
    const char *pMsgString;

public:    
    MsgJsonString(const char *pMsgBody);
    MsgJsonString(int nJsonType, int nMsgtype);
    virtual ~MsgJsonString();
    switch_status_t JsonStringParse();
    const char *GetJsonString();
};



template <class NodeType> 
Json_List<NodeType>::Json_List():nListCount(0), pObjListNodes(NULL)
{
}

template <class NodeType>
Json_List<NodeType>:: ~Json_List()
{
    if(nListCount> 0)
    {
        delete [] pObjListNodes;
    }
}    

template <class NodeType> 
cJSON *Json_List<NodeType>::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;
   
    cJSON *pJson = cJSON_CreateArray();
    cJSON *pSubJson = NULL;
    int i = 0;
    
    for(i = 0; i < nListCount; i++)
    {
        pSubJson = pObjListNodes[i].Json();
        if(NULL == pSubJson)
        {
            nRet = SWITCH_STATUS_FALSE;
            break;
        }
        else
        {
            cJSON_AddItemToArray(pJson, pSubJson);
        }
        
    }
    
    if(SWITCH_STATUS_FALSE == nRet)
    {
        cJSON_Delete(pJson);  
        pJson = NULL;
    }

    return pJson;
    
}

template <class NodeType> 
switch_status_t Json_List<NodeType>:: DecodeJson(cJSON *pJson)
{
    cJSON *pObjListNodeJson = NULL;
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;
    int i = 0;
    
    if(NULL == pJson)
    {
        return SWITCH_STATUS_FALSE;
    }
    
    nListCount = cJSON_GetArraySize(pJson);
    if(nListCount <= 0)
    {
       
        return SWITCH_STATUS_FALSE;
    }
        
    pObjListNodes = new NodeType[nListCount];
        
    for (i = 0; i < nListCount; i++) 
    {
        pObjListNodeJson = cJSON_GetArrayItem(pJson, i);
        if(pObjListNodeJson)
        {
            nRet = pObjListNodes[i].DecodeJson(pObjListNodeJson);
            if(SWITCH_STATUS_FALSE == nRet)
            {
                break;
            }
        }
        else
        {
            nRet = SWITCH_STATUS_FALSE;
            break;
        }
    }
    
    return nRet; 
}

#else 

template <class NodeType>
class Json_Req_Param :public JsonBase
{
public:
    const char *pDate;
    Json_List<NodeType> *pObjList;
public:

    Json_Req_Param() {pObjList = new Json_List<NodeType>()};
    Json_Req_Param(cJSON *pJson){/*������*/}
    virtual ~Json_Req_Param();   
    virtual cJSON *Json();
    virtual switch_status_t DecodeJson(cJSON *pJson);
      
};

class Json_SubInvalidNotify_Param :public JsonBase
{
public:
    const char *pDate;
    Json_List<Json_SubInvalidNotify_ListNode> *pOldList;
    Json_List<Json_SubInvalidNotify_ListNode> *pNewList;
public:
    Json_SubInvalidNotify_Param();
    virtual ~Json_SubInvalidNotify_Param();
    virtual cJSON *Json();
};


class Json_RestartNotify_Param:public JsonBase
{
public:
    const char *pDate;
    const char *pSbcId;
public:
    Json_RestartNotify_Param();
    virtual cJSON *Json();
};

class Json_Response_Param:public JsonBase
{
public:
    const char      *pDate;
    const char      *pReason;
    list<string>    *pListSuccess;
    list<string>    *pListFailure;
public:
    Json_Response_Param();
    virtual cJSON *Json();   
};

class JsonObj
{
public: 
    enum JsonType
    {
        method =0,
        JsonType_result,
        invalid,
    };
    
    JsonType nJsonType;
    int msgType;
    const char *pJsonrpc;
    const char *pId;
  
    const char *pMethod;
    const char *pResult;
    
    JsonBase *pSubParam;
    
public:
    JsonObj(){pSubParam = new SubParamType()}
    virtual ~JsonObj();
    virtual cJSON *Json();
    virtual switch_status_t DecodeJson(cJSON *pJson);       
};


#endif


#endif

