template <class NodeType>
Json_Req_Param::Json_Req_Param()
{
    pObjList = new Json_List<NodeType>();
}; 

template <class NodeType>
Json_Req_Param::~Json_Req_Param()
{
    delete pObjList;
};  

template <class NodeType>
cJSON *Json_Req_Param::Json()
{
    switch_status_t nRet = SWITCH_STATUS_SUCCESS;

    cJSON *pJson = cJSON_CreateObject();
    cJSON_AddItemToObject(pJson, JSON_DATE_KEY, cJSON_CreateString(pDate));
    cJSON_AddItemToObject(pJson, JSON_OBJLIST_KEY, pObjList->Json());
    
    return pJson;
}

template <class NodeType>
switch_status_t Json_Req_Param::DecodeJson(cJSON *pJson)
{
  switch_status_t nRet = SWITCH_STATUS_SUCCESS;
  cJSON *pListJson = NULL;
  
  if(NULL == pJson)
  {
      return SWITCH_STATUS_FALSE;
  }
  
  GETJSONVALUE_RETURN(pJson, JSON_DATE_KEY, pDate, 1);
  GETJSONOBJ_RETURN(pJson, JSON_OBJLIST_KEY, pListJson, 1);
  nRet = pObjList->DecodeJson(pListJson);
  
  return nRet;
}

template <class SubParamType> 
cJSON *JsonObj::Json()
{
   switch_status_t nRet = SWITCH_STATUS_SUCCESS;
   
   cJSON *pJson = cJSON_CreateObject();

   cJSON_AddItemToObject(pJson, JSON_JSONRPC_KEY,  cJSON_CreateString(pJsonrpc));
   if(pId)
   {
        cJSON_AddItemToObject(pJson, JSON_ID_KEY,   cJSON_CreateString(pId));
   }
   
   if(pMethod)
   {
        nJsonType = method;
   }
   else if(pResult)
   {
        nJsonType = result;
   }
    
   switch(nJsonType)
   {
       case method:
           cJSON_AddItemToObject(pJson, JSON_METHOD_KEY, cJSON_CreateString(pMethod));
           cJSON_AddItemToObject(pJson, JSON_PARAMS_KEY, pSubParam->Json());
           break;
       case result:
           cJSON_AddItemToObject(pJson, JSON_RESULT_KEY, cJSON_CreateString(pResult));
           cJSON_AddItemToObject(pJson, JSON_DATA_KEY, pSubParam->Json());
           break;
       default:
           nRet = SWITCH_STATUS_FALSE;
   }
   
   if(SWITCH_STATUS_FALSE == nRet)
   {
       cJSON_Delete(pJson);
       pJson =  NULL;
   }

   return pJson;
}

template <class SubParamType> 

switch_status_t JsonObj::DecodeJson(cJSON *pJson)
{
   switch_status_t nRet = SWITCH_STATUS_SUCCESS;

   cJSON *pSubJson = NULL;
   if(NULL == pJson)
   {
       return SWITCH_STATUS_FALSE;
   }
   
    

   // ������Ϣ����
   pMethod = cJSON_GetObjectCstr(pJson, JSON_METHOD_KEY);
   if(NULL == pMethod)
   {
       pResult = cJSON_GetObjectCstr(pJson, JSON_RESULT_KEY);
       if(NULL == pResult)
       {
           return SWITCH_STATUS_FALSE;
       }
       else
       {
           msgType = MsgTypeInt(pResult);
           nJsonType = result;
           switch(msgType)
           {
               case MSGTYPE_SUBSCRIBE:
               case MSGTYPE_UNSUBSCRIBE:
               case MSGTYPE_REG_MODIFY:
               case MSGTYPE_REG_DEL:
                   UserData.pData = new Json_Response_Param();
                   break;
               default:
                  return SWITCH_STATUS_FALSE; 

           }
       }
   }
   else
   {
       msgType = MsgTypeInt(pMethod);
       nJsonType = method;

       switch(msgType)
       {
           case MSGTYPE_SUBSCRIBE:
               UserData.pParam = new Json_SubReq_Param(new Json_List<Json_SubReq_ListNode>());
               break;
           case MSGTYPE_UNSUBSCRIBE:
               UserData.pParam = new Json_UnsubReq_Param(new Json_List<Json_UnsubReq_ListNode>());
               break;
               
           case MSGTYPE_REG_MODIFY:
               UserData.pParam = new Json_RegModifyReq_Param(new Json_List<Json_RegModifyReq_ListNode>());
               break;
               
           case MSGTYPE_REG_DEL:
               UserData.pParam = new Json_RegDelReq_Param(new Json_List<Json_RegDelReq_ListNode>());
               break;
               
           default:
              return SWITCH_STATUS_FALSE; 

       }
   }

   // ����

   GETJSONVALUE_RETURN(pJson, JSON_JSONRPC_KEY, pJsonrpc, 1);
   GETJSONVALUE_RETURN(pJson, JSON_ID_KEY, pId, 1);

   if(method == nJsonType)
   {
       GETJSONOBJ_RETURN(pJson, JSON_PARAMS_KEY, pSubJson, 1);
       
       nRet = UserData.pParam->DecodeJson(pSubJson);
   }
   else
   {
       GETJSONOBJ_RETURN(pJson, JSON_DATA_KEY, pSubJson, 1);
       nRet = UserData.pData->DecodeJson(pSubJson);
   }

   return nRet;
   
}


