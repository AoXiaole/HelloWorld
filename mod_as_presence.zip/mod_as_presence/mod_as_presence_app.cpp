#include <switch.h>
#include "mod_as_presence_app.h"
#include "mod_as_presence_event.h"
#include <string>
#include <stdlib.h>

// �ն�״̬ö��ֵ��Ӧ���ַ�����ʼ��
const char * const CTerminalStateTranscation::m_szpState[TERMINAL_STATE_MAX] = {STATE_NULL_STR, STATE_READY_STR, STATE_BUSY_STR};

 /*****************************************************************************
 �� �� ��  : CTerminalManagement
 ��������  : ���캯��
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
CTerminalManagement::CTerminalManagement()
{
    m_nCurIndex = 0;
    memset(m_sznState, 0, sizeof(m_sznState));
    pthread_mutex_init(&m_pstUriIndexLock, NULL); 
    RefreshAllTerminalState();
}

 /*****************************************************************************
 �� �� ��  : ~CTerminalManagement
 ��������  : ��������
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
CTerminalManagement::~CTerminalManagement()
{
}

/*****************************************************************************
 �� �� ��  : GetTerminalState
 ��������  :  ��ȡ�ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ������ն�״̬ ʧ�ܷ���-1
*****************************************************************************/
int CTerminalManagement::GetTerminalState(const char *pcURI)
{
    int nStatus = -1;
    int nIndex = -1;

    if(NULL == pcURI)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nStatus;
    }
    pthread_mutex_lock(&m_pstUriIndexLock);
    if(m_mapUriIndex.find(string(pcURI)) != m_mapUriIndex.end())
    {
        nIndex =  m_mapUriIndex[string(pcURI)];
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    if(-1 != nIndex)
    {
        nStatus = m_sznState[nIndex];
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "GetTerminalState. URI:%s, state:%d, index:%d\n", pcURI, nStatus, nIndex);
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "can not find uri:%s\n", pcURI);
    }
    return nStatus;
}

/*****************************************************************************
 �� �� ��  : ListAllTerminalState
 ��������  :  ��ӡ�����ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ������ն�״̬ ʧ�ܷ���-1
*****************************************************************************/
void CTerminalManagement::ListAllTerminalState()
{
    pthread_mutex_lock(&m_pstUriIndexLock);
    for(map<string, int>::iterator iter=m_mapUriIndex.begin(); iter !=m_mapUriIndex.end(); iter++)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "ListAllTerminalState. URI:%s, status:%d, index:%d\n", 
                                                                    iter->first.c_str(), m_sznState[iter->second], iter->second);
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
}

/*****************************************************************************
 �� �� ��  : UpdateTerminalState
 ��������  :  �����ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0ʧ�ܷ���-1
*****************************************************************************/
int CTerminalManagement::UpdateTerminalState(const char *pcURI, const int nStatus)
{
    int nRet = -1;
    int nIndex = -1;

    if(NULL == pcURI)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }
    
    pthread_mutex_lock(&m_pstUriIndexLock);
    map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
    if(iter != m_mapUriIndex.end())
    {
        nIndex = iter->second;
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    if(-1 != nIndex)
    {
        m_sznState[nIndex] = nStatus;
        nRet = 0;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "UpdateTerminalState. uri:%s, status:%d, index:%d\n",
                                                    pcURI, nStatus, nIndex);
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "can not find uri:%s\n", pcURI);
    }

    return nRet;
}

/*****************************************************************************
 �� �� ��  : ModifyTerminalState
 ��������  :  �޸��ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0 ʧ�ܷ���-1
*****************************************************************************/
int CTerminalManagement::ModifyTerminalState(const char *pcURI)
{
    int nRet = -1;
    int nIndex = -1;
    int nStatus = -1;

    if(NULL == pcURI)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }

    nStatus = GetOneDataBaseTerminalState(pcURI);
    if(nStatus >= 0)
    {
        pthread_mutex_lock(&m_pstUriIndexLock);
        map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
        if(iter != m_mapUriIndex.end())
        {
            nIndex = iter->second;
        }
        if(-1 != nIndex)
        {
            m_sznState[nIndex] = nStatus;
            nRet = 0; 
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "ModifyTerminalState. uri:%s, status:%d, index:%d\n",
                                                                                                    pcURI, nStatus, nIndex);
        }
        else
        {
            if(m_nCurIndex < MAX_TERMINAL_COUNT)
            {
                m_mapUriIndex[string(pcURI)] = m_nCurIndex;
                m_sznState[m_nCurIndex] = nStatus;
                m_nCurIndex++;
                nRet = 0;
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "ModifyTerminalState. add one. uri:%s, status:%d, index:%d\n",
                                                                                                                    pcURI, nStatus, m_nCurIndex-1);
            }
            else
            {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "ModifyTerminalState failed too many terminals\n");
            }
        }
        pthread_mutex_unlock(&m_pstUriIndexLock);
    }
    
    return nRet;
}

/*****************************************************************************
 �� �� ��  : DelTerminalState
 ��������  :  ɾ���ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0 ʧ�ܷ���-1
*****************************************************************************/
int CTerminalManagement::DelTerminalState(const char *pcURI)
{
    int nRet = -1;

    if(NULL == pcURI)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }
    
    pthread_mutex_lock(&m_pstUriIndexLock);
    if(m_mapUriIndex.find(string(pcURI)) != m_mapUriIndex.end())
    {
        m_mapUriIndex.erase(string(pcURI));
        m_nCurIndex--;  
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "DelTerminalState. uri:%s\n", pcURI);
        nRet = 0;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "can not find uri:%s\n", pcURI);
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    return nRet;
}

/*****************************************************************************
 �� �� ��  : RefreshAllTerminalState
 ��������  :  ȥ���ݿ�ˢ�������ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
void CTerminalManagement::RefreshAllTerminalState()
{
    int nArgc = 0;
    int nStatus = -1;
    int nIndex = -1;
    char *pcArgv = NULL;
    char *pcArgvUser[64] = {NULL};
    char szcURL[128] = {0};
    char *pouterPtr = NULL;  
    char *buf = NULL;   
    
    switch_stream_handle_t stream = { 0 };

    SWITCH_STANDARD_STREAM(stream);
    switch_api_execute("list_users", NULL, NULL, &stream);

    buf = (char *)stream.data;
    while((pcArgv = strtok_r(buf, "\n", &pouterPtr))!=NULL)   
    {
        buf = NULL;
        if (0 == switch_separate_string(pcArgv, '|', pcArgvUser, switch_arraylen(pcArgvUser)) || !pcArgvUser[0]
               || !pcArgvUser[2] || !pcArgvUser[1] || !pcArgvUser[4] || (strcmp(pcArgvUser[1], "sbc_public")))
        {
            continue;
        }

        snprintf(szcURL, sizeof(szcURL), "%s@%s", pcArgvUser[0], pcArgvUser[2]);
        if(pcArgvUser[4] && strstr(pcArgvUser[4], "not_registered"))
        {
            nStatus = 0; //δע��
        }
        else if(pcArgvUser[4] && strstr(pcArgvUser[4], "@"))
        {
            nStatus = 1; //�Ѿ�ע��
        }
        else
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "err line:%s\n", pcArgv);
            continue;
        }
        
        pthread_mutex_lock(&m_pstUriIndexLock);
        map<string, int>::iterator iter=m_mapUriIndex.find(string(szcURL));
        nIndex = -1;
        if(iter != m_mapUriIndex.end())
        {
            nIndex = iter->second;
        }
        if(-1 != nIndex)
        {
            m_sznState[nIndex] = nStatus;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "RefreshAllTerminalState. uri:%s, status:%d, index:%d\n",
                                                        szcURL, nStatus, nIndex);
        }
        else
        {
            if(m_nCurIndex < MAX_TERMINAL_COUNT)
            {
                m_mapUriIndex[string(szcURL)] = m_nCurIndex;
                m_sznState[m_nCurIndex] = nStatus;
                m_nCurIndex++;
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "RefreshAllTerminalState. uri:%s, status:%d, index:%d\n",
                                                            szcURL, nStatus, m_nCurIndex-1);
            }
            else
            {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "ModifyTerminalState failed too many terminals\n");
            }
        }
        pthread_mutex_unlock(&m_pstUriIndexLock);
    }
    switch_safe_free(stream.data);
}

/*****************************************************************************
 �� �� ��  : RefreshOneTerminalState
 ��������  :  ȥ���ݿ�ˢ��һ��ָ�����ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0�� ʧ�ܷ���-1
*****************************************************************************/
int CTerminalManagement::RefreshOneTerminalState(const char *pcURI)
{
    int nRet = -1;
    int nIndex = -1;
    int nStatus = -1;

    if(NULL == pcURI)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nStatus;
    }


    nStatus = GetOneDataBaseTerminalState(pcURI);
    if(nStatus >= 0)
    {
        pthread_mutex_lock(&m_pstUriIndexLock);
        map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
        if(iter != m_mapUriIndex.end())
        {
            nIndex = iter->second;
        }
        pthread_mutex_unlock(&m_pstUriIndexLock);
        if(-1 != nIndex)
        {
            m_sznState[nIndex] = nStatus;
            nRet = 0; 
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "RefreshOneTerminalState. uri:%s, status:%d, index:%d\n",
                                                        pcURI, nStatus, nIndex);
        }
        else
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "can not find terminal. uri:%s\n", pcURI);
        }
    }
    return nRet;
}

/*****************************************************************************
 �� �� ��  : GetOneDataBaseTerminalState
 ��������  :  ȥ���ݿ�ˢȡһ��ָ�����ն�״̬
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ����ض�Ӧ��״̬�� ʧ�ܷ���-1
*****************************************************************************/
int CTerminalManagement::GetOneDataBaseTerminalState(const char *pcURI)
{
    int nArgc = 0;
    int nStatus = -1;
    char *pcArgv = NULL;
    char *pcArgvUser[64] = {NULL};
    char szcURL[128] = {0};
    char *pouterPtr = NULL;  
    char *buf = NULL;   
    
    switch_stream_handle_t stream = { 0 };

    SWITCH_STANDARD_STREAM(stream);
    switch_api_execute("list_users", NULL, NULL, &stream);

    buf = (char *)stream.data;
    while((pcArgv = strtok_r(buf, "\n", &pouterPtr))!=NULL)   
    {
        buf = NULL;

        if (0 == switch_separate_string(pcArgv, '|', pcArgvUser, switch_arraylen(pcArgvUser)) || !pcArgvUser[0]
               || !pcArgvUser[2] || !pcArgvUser[1] || !pcArgvUser[4] || (strcmp(pcArgvUser[1], "sbc_public")))
        {
            continue;
        }

        snprintf(szcURL, sizeof(szcURL), "%s@%s", pcArgvUser[0], pcArgvUser[2]);
        if(!strncmp(szcURL, pcURI, strlen(pcURI)))
        {
            if(pcArgvUser[4] && strstr(pcArgvUser[4], "not_registered"))
            {
                nStatus = 0; //δע��
            }
            else if(pcArgvUser[4] && strstr(pcArgvUser[4], "@"))
            {
                nStatus = 1; //�Ѿ�ע��
            }
            else
            {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "err line:%s\n", pcArgv);
            }
            break;
        }
    }
    switch_safe_free(stream.data);
    return nStatus;
}

 /*****************************************************************************
 �� �� ��  : CSubscriptitonRelationManagement
 ��������  : ���캯��
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
CSubscriptitonRelationManagement::CSubscriptitonRelationManagement()
{
    pthread_mutex_init(&m_pstUriIndexLock, NULL); 
    memset(&m_szstRelationInfo, 0, sizeof(m_szstRelationInfo));
    m_nCurIndex = 0;
}

 /*****************************************************************************
 �� �� ��  : ~CSubscriptitonRelationManagement
 ��������  : ��������
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
CSubscriptitonRelationManagement::~CSubscriptitonRelationManagement()
{
}

/*****************************************************************************
 �� �� ��  : AddRelation
 ��������  :  ���Ӷ��Ĺ�ϵ
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0�� ʧ�ܷ���-1
*****************************************************************************/
int CSubscriptitonRelationManagement::AddRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount)
{
    int nRet = -1;

    if(NULL == pcURI || NULL == pcSeatGwId || NULL == pcAccount)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }
    pthread_mutex_lock(&m_pstUriIndexLock);
    if(m_nCurIndex < MAX_TERMINAL_COUNT)
    {
        m_mapUriIndex[string(pcURI)] = m_nCurIndex;
        strncpy(m_szstRelationInfo[m_nCurIndex].m_szcSeatGwId, pcSeatGwId, MAX_SEATGWID_LEN);
        strncpy(m_szstRelationInfo[m_nCurIndex].m_szcAccount, pcAccount, MAX_ACCOUNT_LEN);
        m_nCurIndex++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "add one relation uri:%s, seatgwid:%s, account:%s, index:%d\n", 
                                                                                    pcURI, pcSeatGwId, pcAccount, m_nCurIndex-1);        
        nRet = 0;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AddRelation failed too many terminals\n");
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    return nRet;
}

/*****************************************************************************
 �� �� ��  : DelRelation
 ��������  :  ɾ�����Ĺ�ϵ
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0�� ʧ�ܷ���-1
*****************************************************************************/
int CSubscriptitonRelationManagement::DelRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount)
{
    int nRet = -1;
    int nIndex = -1;

    if(NULL == pcURI || NULL == pcSeatGwId || NULL == pcAccount)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }
    pthread_mutex_lock(&m_pstUriIndexLock);
    map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
    if(iter != m_mapUriIndex.end())
    {
        nIndex = iter->second;
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    if(-1 != nIndex)
    {
        if(!strncmp(m_szstRelationInfo[nIndex].m_szcAccount, pcAccount, MAX_ACCOUNT_LEN)
                && !strncmp(m_szstRelationInfo[nIndex].m_szcSeatGwId, pcSeatGwId, MAX_SEATGWID_LEN))
        {
            pthread_mutex_lock(&m_pstUriIndexLock);
            m_mapUriIndex.erase(string(pcURI));
            m_nCurIndex--;
            pthread_mutex_unlock(&m_pstUriIndexLock);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "delete relation uri:%s, seatgwid:%s, account:%s, index:%d\n", 
                                                                                pcURI, pcSeatGwId, pcAccount, nIndex);
            nRet = 0;
        }                                                                   
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "can not find relation uri:%s, seatgwid:%s, account:%s\n", pcURI);
    }
    return nRet;
}

/*****************************************************************************
 �� �� ��  : UpdateRelation
 ��������  :  ���¶��Ĺ�ϵ
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0�� ʧ�ܷ���-1
*****************************************************************************/
int CSubscriptitonRelationManagement::UpdateRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount)
{
    int nRet = -1;
    int nIndex = -1;

    if(NULL == pcURI || NULL == pcSeatGwId || NULL == pcAccount)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }
    pthread_mutex_lock(&m_pstUriIndexLock);
    map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
    if(iter != m_mapUriIndex.end())
    {
        nIndex = iter->second;
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    if(-1 != nIndex)
    {
        strncpy(m_szstRelationInfo[nIndex].m_szcSeatGwId, pcSeatGwId, MAX_SEATGWID_LEN);
        strncpy(m_szstRelationInfo[nIndex].m_szcAccount, pcAccount, MAX_ACCOUNT_LEN);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "refresh relation uri:%s, seatgwid:%s, account:%s, index:%d\n",
                                                                                         pcURI, pcSeatGwId, pcAccount, nIndex);
        nRet = 0;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "can not find relation uri:%s\n", pcURI);
    }
    return nRet;
}

/*****************************************************************************
 �� �� ��  : CheckRelation
 ��������  :  ����Ƿ������صĶ��Ĺ�ϵ
 �������  : 
 �������  :
 �� �� ֵ  : �ɹ�����0�� ʧ�ܷ���-1
*****************************************************************************/
int CSubscriptitonRelationManagement::CheckRelation(const char *pcURI, const char *pcSeatGwId, const char *pcAccount)
{
    int nRet = -1;
    int nIndex = -1;
    
    if(NULL == pcURI || NULL == pcSeatGwId || NULL == pcAccount)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }

    pthread_mutex_lock(&m_pstUriIndexLock);
    map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
    if(iter != m_mapUriIndex.end())
    {
        nIndex = iter->second;
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    if(-1 != nIndex)
    {
        if(!strncmp(m_szstRelationInfo[nIndex].m_szcAccount, pcAccount, MAX_ACCOUNT_LEN)
                && !strncmp(m_szstRelationInfo[nIndex].m_szcSeatGwId, pcSeatGwId, MAX_SEATGWID_LEN))
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "find relation uri:%s, seatgwid:%s, account:%s\n", 
                                                                                pcURI, pcSeatGwId, pcAccount);
            nRet = 0;
        }
    }
    else
    {
        nRet = AddRelation(pcURI, pcSeatGwId, pcAccount);
    }
    
    return nRet;
}

/*****************************************************************************
 �� �� ��  : GetRelation
 ��������  :  ��ȡ��صĶ��Ĺ�ϵ
 �������  : 
 �������  :pcSeatGwId, pcAccount
 �� �� ֵ  : �ɹ�����0�� ʧ�ܷ���-1
*****************************************************************************/
int CSubscriptitonRelationManagement::GetRelation(const char *pcURI, char *pcSeatGwId, int nSeatGwIdLen, char *pcAccount, int nAccountLen)
{
    int nRet = -1;
    int nIndex = -1;

    if(NULL == pcURI || NULL == pcSeatGwId || NULL == pcAccount)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "input para err\n");
        return nRet;
    }
    pthread_mutex_lock(&m_pstUriIndexLock);
    map<string, int>::iterator iter=m_mapUriIndex.find(string(pcURI));
    if(iter != m_mapUriIndex.end())
    {
        nIndex = iter->second;
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
    if(-1 != nIndex)
    {
        strncpy(pcSeatGwId, m_szstRelationInfo[nIndex].m_szcSeatGwId, nSeatGwIdLen);
        strncpy(pcAccount, m_szstRelationInfo[nIndex].m_szcAccount, nAccountLen);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "get relation uri:%s, seatgwid:%s, account:%s, index:%d\n",
                                                                                         pcURI, pcSeatGwId, pcAccount, nIndex);
        nRet = 0;
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "can not find relation uri:%s\n", pcURI);
    }
    return nRet;
}

/*****************************************************************************
 �� �� ��  : ListAllRelation
 ��������  :  ��ӡ���ж��Ĺ�ϵ
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
void CSubscriptitonRelationManagement::ListAllRelation()
{
    int nIndex = -1;

    pthread_mutex_lock(&m_pstUriIndexLock);
    for(map<string, int>::iterator iter = m_mapUriIndex.begin(); iter != m_mapUriIndex.end(); iter++)
    {
        nIndex = iter->second;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "get relation uri:%s, seatgwid:%s, account:%s, index:%d\n",
                       iter->first.c_str(), m_szstRelationInfo[iter->second].m_szcSeatGwId, m_szstRelationInfo[iter->second].m_szcAccount, iter->second);
    }
    pthread_mutex_unlock(&m_pstUriIndexLock);
}


 /*****************************************************************************
 �� �� ��  : CTerminalStateTranscation
 ��������  : ���캯��
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/
CTerminalStateTranscation::CTerminalStateTranscation()
{
    int nSubscribeEvent;
    int nCallingState;
    int nCurTerminalStatus;
    int nNextTerminalStatus;

    // [ ESL_SUBSCRIBE_EVENT_REGISTERED ] [ESL_CALLING_STATE_HANGUP] [-] = TERMINAL_STATE_READY
    for(nCurTerminalStatus = TERMINAL_STATE_NULL; nCurTerminalStatus < TERMINAL_STATE_MAX; nCurTerminalStatus++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_REGISTERED][ESL_CALLING_STATE_HANGUP][nCurTerminalStatus]   = TERMINAL_STATE_READY;
    }

     // [ ESL_SUBSCRIBE_EVENT_REGISTERED ] [ESL_CALLING_STATE_NULL] [-] = TERMINAL_STATE_READY
    for(nCurTerminalStatus = TERMINAL_STATE_NULL; nCurTerminalStatus < TERMINAL_STATE_MAX; nCurTerminalStatus++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_REGISTERED][ESL_CALLING_STATE_NULL][nCurTerminalStatus]   = TERMINAL_STATE_READY;
    }

    // [ ESL_SUBSCRIBE_EVENT_REGISTERED ] [ESL_CALLING_STATE_OTHER] [-] = TERMINAL_STATE_BUSY
    for(nCurTerminalStatus = TERMINAL_STATE_NULL; nCurTerminalStatus < TERMINAL_STATE_MAX; nCurTerminalStatus++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_REGISTERED][ESL_CALLING_STATE_OTHER][nCurTerminalStatus]   = TERMINAL_STATE_BUSY;
    }


    // [ ESL_SUBSCRIBE_EVENT_UNREGISTERED ] [-] [-] = TERMINAL_STATE_NULL
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        for(nCurTerminalStatus = TERMINAL_STATE_NULL; nCurTerminalStatus < TERMINAL_STATE_MAX; nCurTerminalStatus++)
        {
            m_szStateTable[ESL_SUBSCRIBE_EVENT_UNREGISTERED][nCallingState][nCurTerminalStatus]   = TERMINAL_STATE_NULL;
        }
    }

    // [ ESL_SUBSCRIBE_EVENT_HANGUP ] [-] [TERMINAL_STATE_NULL] = TERMINAL_STATE_NULL
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_HANGUP][nCallingState][TERMINAL_STATE_NULL]   = TERMINAL_STATE_NULL;
    }

    // [ ESL_SUBSCRIBE_EVENT_HANGUP ] [-] [TERMINAL_STATE_BUSY] = TERMINAL_STATE_READY
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_HANGUP][nCallingState][TERMINAL_STATE_BUSY]   = TERMINAL_STATE_READY;
    }

    // [ ESL_SUBSCRIBE_EVENT_HANGUP ] [-] [TERMINAL_STATE_READY] = TERMINAL_STATE_READY 
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_HANGUP][nCallingState][TERMINAL_STATE_READY]   = TERMINAL_STATE_READY;
    }

    // [ ESL_SUBSCRIBE_EVENT_OTHER ] [-] [TERMINAL_STATE_NULL] = TERMINAL_STATE_NULL 
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_OTHER][nCallingState][TERMINAL_STATE_NULL]   = TERMINAL_STATE_NULL;
    }

    // [ ESL_SUBSCRIBE_EVENT_OTHER ] [-] [TERMINAL_STATE_BUSY] = TERMINAL_STATE_BUSY 
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_OTHER][nCallingState][TERMINAL_STATE_BUSY]   = TERMINAL_STATE_BUSY;
    }

     // [ ESL_SUBSCRIBE_EVENT_OTHER ] [-] [TERMINAL_STATE_READY] = TERMINAL_STATE_BUSY 
    for(nCallingState = ESL_CALLING_STATE_HANGUP; nCallingState < ESL_CALLING_STATE_MAX; nCallingState++)
    {
        m_szStateTable[ESL_SUBSCRIBE_EVENT_OTHER][nCallingState][TERMINAL_STATE_READY]   = TERMINAL_STATE_BUSY;
    }

}

 /*****************************************************************************
 �� �� ��  : ~CTerminalStateTranscation
 ��������  : ��������
 �������  : 
 �������  :
 �� �� ֵ  : 
*****************************************************************************/

CTerminalStateTranscation::~CTerminalStateTranscation()
{

}
 
/*****************************************************************************
  �� �� ��  : Transaction
  ��������  : ���ߵ�ǰ״̬���¼���ȡ��һ��״̬
  �������  : 
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
int CTerminalStateTranscation::Transaction(int nSubscribeEvent, int nCallingState, int nCurTerminalState)
{
    if((ESL_SUBSCRIBE_EVENT_MAX > nSubscribeEvent && 0 <= nSubscribeEvent) && 
       (ESL_CALLING_STATE_MAX > nCallingState  && 0 <= nCallingState) && 
       (TERMINAL_STATE_MAX > nCurTerminalState && 0 <= nCurTerminalState))
    {
        return (int)m_szStateTable[nSubscribeEvent][nCallingState][nCurTerminalState];
    }
    else
    {
        return (int)TERMINAL_STATE_MAX;
    }
}

/*****************************************************************************
  �� �� ��  : GetStateInt
  ��������  : ��״̬���ַ���ת��Ϊint
  �������  : 
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
int CTerminalStateTranscation::GetStateInt(const char *pSate)
{
    int nState = TERMINAL_STATE_MAX;
    if(NULL == pSate)
    {
        return nState;
    }

    for (nState = TERMINAL_STATE_NULL; nState < TERMINAL_STATE_MAX; nState++)
    {
        if(strcmp(pSate, m_szpState[nState]) == 0)
        {
            break;
        }
    }
    
    return nState;
}


/*****************************************************************************
  �� �� ��  : GetStateString
  ��������  : �����ε�״ֵ̬ת��Ϊ�ַ�
  �������  : 
  �������  :
  �� �� ֵ  : 
*****************************************************************************/
const char * CTerminalStateTranscation::GetStateString(int nState)
{
    if(TERMINAL_STATE_MAX <= nState || 0 > nState)
    {
        return NULL;
    }
    
    return m_szpState[nState];
}

