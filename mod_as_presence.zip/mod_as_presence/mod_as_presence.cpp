#include <switch.h>
#include "mod_as_presence_app.h"
#include "mod_as_presence_event.h"
#include "mod_as_presence_redis.h"

CTerminalManagement *g_cTerminalManagement = NULL;
CSubscriptitonRelationManagement *g_cSubscriptitonRelationManagement = NULL;
CTerminalStateTranscation *g_cTerminalStateTranscation = NULL;
SBCINFO sbcinfo = {0};

SWITCH_MODULE_LOAD_FUNCTION(mod_as_presence_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_as_presence_shutdown);
SWITCH_MODULE_DEFINITION(mod_as_presence, mod_as_presence_load, mod_as_presence_shutdown, NULL);

static void mod_as_presence_sbcinfo_init(const char *pSbcId, const char *pSbcIp)
{
    memset(&sbcinfo, 0, sizeof(sbcinfo));
    strncpy(sbcinfo.szSbcId, pSbcId, SBCID_LEN);
    strncpy(sbcinfo.szIp, pSbcIp, SBCID_LEN);

    switch_snprintf(sbcinfo.szSbcQueueName, QUEUENAME_LEN, "q_%s", pSbcId);
    switch_snprintf(sbcinfo.szSbcWebQueueName, QUEUENAME_LEN, "q_web_%s", pSbcId);
    switch_snprintf(sbcinfo.szSeatGwEvent, SUBEVENT_LEN,"%s_%s", MQ_SUBEVENT_RECEIVE, sbcinfo.szSbcQueueName);
    switch_snprintf(sbcinfo.szWebEvent, SUBEVENT_LEN,"%s_%s", MQ_SUBEVENT_RECEIVE, sbcinfo.szSbcWebQueueName);
    
    sbcinfo.pModuleName = SBC_MODULENAME;    
}

static switch_status_t mod_as_presence_init(const char *pModname)
{
    char *pSbcIp = NULL;
    char szSbcId[SBCID_LEN + 1] = {0};
    switch_status_t status = SWITCH_STATUS_FALSE;
    int counts = 5;
    // 2.��ȡsbcid 
    pSbcIp = (char*)switch_core_get_variable("local_ip_v4");
    status = as_presence_redis_get_sbcid(pSbcIp, szSbcId);
    if(SWITCH_STATUS_FALSE == status)
    {
        return status;
    }

    mod_as_presence_sbcinfo_init(szSbcId, pSbcIp);

     // ����MQ��seatgw ���¼�
    if(switch_event_bind(pModname, SWITCH_EVENT_CUSTOM, sbcinfo.szSeatGwEvent, as_presence_MQmsg_event_handler, NULL))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't bind SWITCH_EVENT_CHANNEL_HANGUP!\n");
        goto switch_event_bind1_ERROR;
    }

    // ����MQ ��web ���¼�
    if(switch_event_bind(pModname, SWITCH_EVENT_CUSTOM, sbcinfo.szWebEvent, as_presence_MQmsg_event_handler, NULL))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't bind SWITCH_EVENT_CHANNEL_HANGUP!\n");
        
        goto switch_event_bind2_ERROR;
    }

    // ��mq���Ͷ����¼�
    while(counts--)
    {
        if(sbcinfo.nSbcQueueSubFlag && sbcinfo.nSbcWebQueueSubFlag)
        {
            break;
        }
        
        if(sbcinfo.nSbcQueueSubFlag == 0)
        {
            status = as_presence_send_subMQmsg(sbcinfo.szSbcQueueName);
            if(SWITCH_STATUS_FALSE == status)
            {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                    "%s as_presence_send_subMQmsg error\n", __FUNCTION__); 
                goto as_presence_send_subMQmsg_error;
                
            }
        }

        if(sbcinfo.nSbcWebQueueSubFlag == 0)
        {
            status = as_presence_send_subMQmsg(sbcinfo.szSbcWebQueueName);
            if(SWITCH_STATUS_FALSE == status)
            {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                    "%s as_presence_send_subMQmsg error\n", __FUNCTION__); 
                goto as_presence_send_subMQmsg_error;
                
            }
        }

        usleep(500 * 1000);
        
    }
    
    if(counts == 0)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s subscrible rabbite mq error\n", __FUNCTION__); 
        goto as_presence_sendMQ_restart_ERROR;
    }
    
    // 4.�㲥seatGW sbc ����
    status = as_presence_sendMQ_restart(sbcinfo.szSbcId);
    if(SWITCH_STATUS_FALSE == status)
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s as_presence_sendMQ_restart error\n", __FUNCTION__); 
        goto as_presence_sendMQ_restart_ERROR;
        
    }
    
    return SWITCH_STATUS_SUCCESS;
    
as_presence_sendMQ_restart_ERROR:   
as_presence_send_subMQmsg_error:
switch_event_bind2_ERROR:
    switch_event_unbind_callback(as_presence_MQmsg_event_handler);
switch_event_bind1_ERROR:
    return SWITCH_STATUS_FALSE;
    
}

static switch_status_t mod_as_presence_deInit()
{
    switch_event_unbind_callback(as_presence_MQmsg_event_handler);
    return SWITCH_STATUS_SUCCESS;
}

static switch_status_t testMq(char *pmMsgBody)
{

    switch_status_t nRet = SWITCH_STATUS_FALSE;
    switch_event_t *pevent = NULL;
    
    if(SWITCH_STATUS_SUCCESS == switch_event_create_subclass(&pevent, SWITCH_EVENT_CUSTOM, sbcinfo.szSeatGwEvent))
    {
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_MSGBODY_STR, pmMsgBody);
        switch_event_add_header_string(pevent, SWITCH_STACK_BOTTOM, MQMSG_TYPE_STR, "recv");
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, 
            "[PRINTF_DEBUG] "
            MQMSG_MSGBODY_STR ":%s\n\n\n\n",
            pmMsgBody
            );
    
        switch_event_fire(&pevent); 
       // test
        nRet = SWITCH_STATUS_SUCCESS;
        
    }
    else
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Create event failed");
        nRet = SWITCH_STATUS_FALSE;
    }
    return nRet;
    
}


switch_status_t as_presence_api(_In_opt_z_ const char *cmd, _In_ switch_stream_handle_t *stream)
{
    char *argv[16] = {NULL};
    int argc = 0;
    char *mycmd = NULL;
    switch_status_t status = SWITCH_STATUS_SUCCESS;
    static const char usage_string[] = "USAGE:\n"
        "--------------------------------------------------------------------------------\n"
        "as_presence DelTerminalStatus\n"
        "as_presence ModifyTerminalStatus\n"
        "as_presence GetTerminalStatus\n"
        "as_presence UpdateTerminalStatus\n"
        "as_presence RefreshOneTerminalStatus\n"
        "as_presence RefreshAllTerminalStatus\n"
        "as_presence ListAllTerminalStatus\n"
        "as_presence AddRelation\n"
        "as_presence DelRelation\n"
        "as_presence UpdateRelation\n"
        "as_presence CheckRelation\n"
        "as_presence GetRelation\n"
        "as_presence ListAllRelation\n"
        "--------------------------------------------------------------------------------\n";

    if (zstr(cmd) || NULL == g_cTerminalManagement || NULL == g_cSubscriptitonRelationManagement || NULL == g_cTerminalStateTranscation) 
    {
        stream->write_function(stream, "%s", usage_string);
        goto GOTO_as_presence_api_function_done_flag;
    }

    if (!(mycmd = strdup(cmd))) 
    {
        status = SWITCH_STATUS_MEMERR;
        goto GOTO_as_presence_api_function_done_flag;
    }

    if (!(argc = switch_separate_string(mycmd, ' ', argv, switch_arraylen(argv))) || !argv[0]) 
    {
        stream->write_function(stream, "%s", usage_string);
        goto GOTO_as_presence_api_function_done_flag;
    }

    // test
    if(!strncmp(argv[0], "sendmq", strlen(argv[0])))
    {
        testMq(argv[1]);
    }
    //
    else if (!strncmp(argv[0], "DelTerminalStatus", strlen(argv[0]))) 
    {
        g_cTerminalManagement->DelTerminalState(argv[1]);
    }
    else if(!strncmp(argv[0], "ModifyTerminalStatus", strlen(argv[0])))
    {
        g_cTerminalManagement->ModifyTerminalState(argv[1]);
    }
    else if(!strncmp(argv[0], "GetTerminalStatus", strlen(argv[0])))
    {
        g_cTerminalManagement->GetTerminalState(argv[1]);
    }
    else if(!strncmp(argv[0], "UpdateTerminalStatus", strlen(argv[0])))
    {
        if(argv[2])
        {
            g_cTerminalManagement->UpdateTerminalState(argv[1], atoi(argv[2]));
        }
        else
        {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "no status para!!\n");
            stream->write_function(stream, "no status para!!\n");
        }
    }
    else if(!strncmp(argv[0], "RefreshOneTerminalStatus", strlen(argv[0])))
    {
        g_cTerminalManagement->RefreshOneTerminalState(argv[1]);
    }
    else if(!strncmp(argv[0], "RefreshAllTerminalStatus", strlen(argv[0])))
    {
        g_cTerminalManagement->RefreshAllTerminalState();
    }
    else if(!strncmp(argv[0], "ListAllTerminalStatus", strlen(argv[0])))
    {
        g_cTerminalManagement->ListAllTerminalState();
    }
    else if(!strncmp(argv[0], "AddRelation", strlen(argv[0])))
    {
        g_cSubscriptitonRelationManagement->AddRelation(argv[1], argv[2], argv[3]);
    }
    else if(!strncmp(argv[0], "DelRelation", strlen(argv[0])))
    {
        g_cSubscriptitonRelationManagement->DelRelation(argv[1], argv[2], argv[3]);
    }
    else if(!strncmp(argv[0], "UpdateRelation", strlen(argv[0])))
    {
        g_cSubscriptitonRelationManagement->UpdateRelation(argv[1], argv[2], argv[3]);
    }
    else if(!strncmp(argv[0], "CheckRelation", strlen(argv[0])))
    {
        g_cSubscriptitonRelationManagement->CheckRelation(argv[1], argv[2], argv[3]);
    }
    else if(!strncmp(argv[0], "GetRelation", strlen(argv[0])))
    {
        char szcSeatId[32] = {0};
        char szcAccountId[32] = {0};
        g_cSubscriptitonRelationManagement->GetRelation(argv[1], szcSeatId, sizeof(szcSeatId), szcAccountId, sizeof(szcAccountId));
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "get relation uri:%s, seatgwid:%s, account:%s\n",
                                                                                         argv[1], szcSeatId, szcAccountId);
    }
    else if(!strncmp(argv[0], "ListAllRelation", strlen(argv[0])))
    {
        g_cSubscriptitonRelationManagement->ListAllRelation();
    }
    else 
    {
        stream->write_function(stream, "Unknown Command [%s]\n", argv[0]);
    }

    stream->write_function(stream, "success\n");
GOTO_as_presence_api_function_done_flag:
    switch_safe_free(mycmd);
    return status;
}


SWITCH_STANDARD_API(as_presence_api_function)
{
    return as_presence_api(cmd, stream);
}

/*****************************************************************************
 �� �� ��  : mod_as_presence_load
 ��������  : ģ�����
             �궨��ԭ�Ͳ鿴switch_types.h 2428��
 �������  : pool: �ڴ��
 �������  : module_interface: ģ��ָ��
 �� �� ֵ  : �ɹ�����SWITCH_STATUS_SUCCESS ʧ�ܷ��ش�����
*****************************************************************************/
SWITCH_MODULE_LOAD_FUNCTION(mod_as_presence_load)
{
    switch_api_interface_t* api_interface = NULL;

    *module_interface = switch_loadable_module_create_module_interface(pool, modname);
	
    /******************* ע��API *******************/
    SWITCH_ADD_API(api_interface, "as_presence", "as_presence api",as_presence_api_function,"<cmd> <args>");


    /******************* �����¼� *******************/
    if(switch_event_bind(modname, SWITCH_EVENT_PRESENCE_IN, SWITCH_EVENT_SUBCLASS_ANY, as_presence_presencein_event_handler, NULL))
    {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't bind SWITCH_EVENT_PRESENCE_IN!\n");
        return SWITCH_STATUS_FALSE;
    }
        
    g_cTerminalManagement = new CTerminalManagement;
    g_cSubscriptitonRelationManagement = new CSubscriptitonRelationManagement;
    g_cTerminalStateTranscation = new CTerminalStateTranscation;

    if(mod_as_presence_init(modname) == SWITCH_STATUS_FALSE)
    {
        if(g_cTerminalManagement)
        {
            delete g_cTerminalManagement;
            g_cTerminalManagement = NULL;
        }    
        if(g_cSubscriptitonRelationManagement)
        {
            delete g_cSubscriptitonRelationManagement;
            g_cSubscriptitonRelationManagement = NULL;
        }
        if(g_cTerminalStateTranscation)
        {
            delete g_cTerminalStateTranscation;
            g_cTerminalStateTranscation = NULL;
        }
        switch_event_unbind_callback(as_presence_presencein_event_handler);
        
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_as_presence_init error!\n");
        
        return SWITCH_STATUS_FALSE;
    }
    return SWITCH_STATUS_SUCCESS;
}

/*****************************************************************************
 �� �� ��  : mod_as_presence_shutdown
 ��������  : as_presenceģ���˳�
             �궨��ԭ�Ͳ鿴switch_types.h 2430��
 �������  : pool: �ڴ��
 �������  : module_interface: ģ��ָ��
 �� �� ֵ  : �ɹ�����SWITCH_STATUS_SUCCESS ʧ�ܷ��ش�����
*****************************************************************************/
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_as_presence_shutdown)
{ 

    mod_as_presence_deInit();

    switch_event_unbind_callback(as_presence_presencein_event_handler);
    if(g_cTerminalManagement)
    {
        delete g_cTerminalManagement;
        g_cTerminalManagement = NULL;
    }    
    if(g_cSubscriptitonRelationManagement)
    {
        delete g_cSubscriptitonRelationManagement;
        g_cSubscriptitonRelationManagement = NULL;
    }
    if(g_cTerminalStateTranscation)
    {
        delete g_cTerminalStateTranscation;
        g_cTerminalStateTranscation = NULL;
    }
    return SWITCH_STATUS_SUCCESS;
}

