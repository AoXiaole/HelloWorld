#ifndef __MOD_AS_PRESENCE_REDIS_H__
#define __MOD_AS_PRESENCE_REDIS_H__
#include <switch.h>
#include "mod_as_presence_jsonrpc.h"
#define REDIS_TERMINAL_INFO_LEN    256
#define REDIS_SBC_INFO_LEN    256

switch_status_t as_presence_redis_get_sbc_info(const char *pSbcIp, char *pSbcInfoStr);
switch_status_t as_presence_redis_get_terminal_info(const char *pTermURI, char *pTerminaInfo);
switch_status_t as_presence_redis_get_sbcid(const char *pSbcIp, char *pSbcId);
switch_status_t as_presence_redis_get_terminal_state(const char *pTermURI, char *pTerminalStateStr);
switch_status_t as_presence_redis_set_terminal_state(const char *pTermURI, const char *pTerminalStateStr);

#endif
